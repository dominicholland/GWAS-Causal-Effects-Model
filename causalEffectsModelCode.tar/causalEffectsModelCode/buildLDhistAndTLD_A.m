
% Dominic Holland
% https://www.biorxiv.org/content/early/2018/06/07/133132

% buildLDhistAndTLD_A.m

% Elements of genomats are -1, 0, 1, and 2

% See ~/matlab/SynGP/buildLDhistAndTLD_HapGen_A.m:
% Optionally, restrict G to the 11M SNPs that are in HapGen and for which less than 1 percent of subjects have genotype==0

 EXCLUDE_EVERY_OTHER_SNP = false;
%EXCLUDE_EVERY_OTHER_SNP = true;
 
%RESTRICT_TO_HAPGEN_1PC = false;
 RESTRICT_TO_HAPGEN_1PC = true;
 
 ZERO_OUT_NOISE = true;
%ZERO_OUT_NOISE = false;
%noiseThreshold_r2 = 0.05;  % E.g., 0.05 ==> noiseThreshold_r = sqrt(noiseThreshold_r2) = 0.2236 : For r^2<0.05 set r^2 to 0.
 noiseThreshold_r2 = 0.01;

 outDir = '/space/md10/8/data/holland/genetics/LDhistAndTLD_1kGPhase3_hg19';
if ~exist( outDir, 'dir'),  mkdir(outDir);  end;  fprintf(1, 'outDir is %s\n', outDir);

C_fullFileName = [outDir '/chr.mat'];
G_fullFileName = [outDir '/G.mat'];          % Contains G (500 X 14933168)
%M_fullFileName = [outDir '/mafvec.mat'];

if ~exist(C_fullFileName, 'file') | ~exist(G_fullFileName, 'file')  % | ~exist(M_fullFileName, 'file')

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if 0
  chr = [];
  A1 = [];
  A2 = [];
  posvec_cM = [];
  posvec_bp = [];
  snpidlist = [];
  genomats = [];
  % load 1kGP european data from plink binary format
  for i = 1:22;
    fname = ...
    sprintf('/space/syn03/1/data/cfan/1000Genome/phase3/build37_released/plink_binary/EUR.chr%d.phase3_shapeit2_mvncall_integrated_v5a.20130502.genotypes.vcf.gz',i);    % <-- Phase 3
   %sprintf('/space/md16/2/data/MMILDB/AMD_IGG/Genetics/1000Genomes/plink/EUR/chromosome%d_relQC',i);                                                                    % <-- Phase 1
    [chrvec, snplist, A1vec, A2vec, cMvec, bpvec, FID, IID, sexvec, phenovec, genomat] = PlinkRead_binary(fname);
   %[chrvec, snplist,                                                         genomat] = PlinkRead_binary_minimal(fname);
   %[chrvec, snplist, A1vec, A2vec,               FID, IID, sexvec, phenovec, genomat] = PlinkRead_binary(fname);
    chr = [chr;chrvec];                  % cell
    A1 = [A1;A1vec];                     % cell
    A2 = [A2;A2vec];                     % cell
    posvec_cM = [posvec_cM;cMvec];       % int32
    posvec_bp = [posvec_bp;bpvec];       % int32
    snpidlist = [snpidlist;snplist];     % cell                                                  % 81,271,745
    genomats = cat(2,genomats,genomat);  % int8
  end
  end  % if 0
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  NSNPTOTAL   = 81271745;
  NSUBJSTOTAL = 503;
  chr       = zeros(1,NSNPTOTAL,'int8');
  posvec_cM = zeros(1,NSNPTOTAL,'int32');
  posvec_bp = zeros(1,NSNPTOTAL,'int32');
  genomats = -1*ones(NSUBJSTOTAL, NSNPTOTAL, 'int8');
  snpidlist = [];    % <---- better way to handle this?
  % load 1kGP european data from plink binary format
  n0 = 0;
  for i = 1:22;
    fname = ...
    sprintf('/space/syn03/1/data/cfan/1000Genome/phase3/build37_released/plink_binary/EUR.chr%d.phase3_shapeit2_mvncall_integrated_v5a.20130502.genotypes.vcf.gz',i);    % <-- Phase 3
   %sprintf('/space/md16/2/data/MMILDB/AMD_IGG/Genetics/1000Genomes/plink/EUR/chromosome%d_relQC',i);                                                                    % <-- Phase 1
    [chrvec, snplist, A1vec, A2vec, cMvec, bpvec, FID, IID, sexvec, phenovec, genomat] = PlinkRead_binary(fname);
   %[chrvec, snplist,                                                         genomat] = PlinkRead_binary_minimal(fname);
   %[chrvec, snplist, A1vec, A2vec,               FID, IID, sexvec, phenovec, genomat] = PlinkRead_binary(fname);
    nsnpCurr = size(chrvec,1);
    n1 = n0 + nsnpCurr;
    chrvec_int8 = int8(str2num(cell2mat(chrvec)));
    chr(n0+1:n1) = chrvec_int8;                   % int8
    posvec_cM(n0+1:n1) = cMvec;                   % int32
    posvec_bp(n0+1:n1) = bpvec;                   % int32
    snpidlist = [snpidlist;snplist];              % cell                                                  % 81,271,745
    if size(genomat,1) ~= NSUBJSTOTAL,  keyboard;  end
    genomats(:,n0+1:n1) = genomat;                % int8
    n0=n1;
    if n0 > NSNPTOTAL,  keyboard;  end
  end


  % 80.7012 GB at this point.
  
  % genomats is  503 x 81271745;  NOTE for HapGen simulated data, genomats is  1000 x 80378054;
  
  clear chrvec snplist A1vec A2vec FID IID sexvec phenovec genomat;
  clear A1 A2;
  
  nsubj = size(genomats,1);  % 376 for Phase 1,  503 for Phase 3.
  
  % PLAN: Get rid of SNPs for which (1), (2), or (3) apply:
  % (1) SNPs with no heterozygosity (zero variation in allele count, i.e., maf==0 --> for a given SNP all subjects have [minor allele] genotype=0, so that maf==0; maf==1 is a contradiction in terms --> all have genotype=2);
  %     Note: if all subjects have genotype=1, this implies nonzero variation, given by the heterozygosity: H = 2*maf*(1-maf) = 0.5;
  % (2) Singleton SNPs (SNPs for which only 1 subject has a different allele count to all the other subjects);
  % (3) SNPs for which the call rate is less than 90% (i.e., for which less than 90 percent of subjects have useful data (useful data means 0, 1, or 2 for allele count, not -1).
  % 
  % For (3), 90 percent seems reasonable. Don''t want it too low at least partly because missing allele count will be replaced by the mean: the more missing SNPs there are, the greater the impact of this change.
  % Don''t want it too high because then one is eliminating potentially useful/informative SNPs that "just happen" to be missing a few subjects.
  % (What are the reasons behind missingness? If there are even a few missing subjects for a SNP, is that indicative of a real problem with that SNP?)
  % 
  % This leads to snpsToEliminate as defined below.
  
  % Some subjects have "-1" for allele count: these need to be excluded from the tallies.
  nsubjsWithSNPData_vec = nsubj-sum(genomats==-1,1);
  %nsubjsWithSNPData_99percentile_vec = nsubjsWithSNPData_vec - round(0.01*(nsubjsWithSNPData_vec));
  
  % For removing SNPs with zero heterozygopsity AND singletons:
  %snpsWithLowVariationIndsLogical = sum(~genomats,1)   >=    nsubjsWithSNPData_vec-1 |...
  
  snpsWithLowVariationIndsLogical = sum(~genomats,1)   >=    nsubjsWithSNPData_vec-1;   % 66308539
  %                                 sum(genomats==2,1) >= 2*(nsubjsWithSNPData_vec-1);  % 1x81271745;  length(find(snpsWithLowVariationIndsLogical1)) --> 66308681;  81271745-66308681 = 14963064
  
  nsubj_80percent = floor(0.80*nsubj);
  nsubj_90percent = floor(0.90*nsubj);
  nsubj_95percent = floor(0.95*nsubj);
  
  snpsWithHighMissingness = nsubjsWithSNPData_vec < nsubj_80percent;   % If less than 80% of subjects have useful data for a SNP, ignore that SNP. length(find(snpsWithHighMissingness)) --> 19657
 %snpsWithHighMissingness = nsubjsWithSNPData_vec < nsubj_90percent;   % If less than 90% of subjects have useful data for a SNP, ignore that SNP. length(find(snpsWithHighMissingness)) --> 30839
 %snpsWithHighMissingness = nsubjsWithSNPData_vec < nsubj_95percent;   % If less than 95% of subjects have useful data for a SNP, ignore that SNP. length(find(snpsWithHighMissingness)) --> 41170
  
  clear  nsubjsWithSNPData_vec;
  
  snpsToEliminate = snpsWithLowVariationIndsLogical | snpsWithHighMissingness;  % length(find(snpsToEliminate))  -->  66338577;      81271745 - 66338577 ==> 14933168 remaining SNPs
  
  snpIndsLogical = ~snpsToEliminate;
  snpInds        = find(snpIndsLogical);
  nsnps          = length(snpInds);        % 14944190 using nsubj_80percent and eliminating SNPs where all but one subject have genotype 0;                old: 14933168
  
  snpidlist = snpidlist(snpInds);
  posvec_cM = posvec_cM(snpInds);
  posvec_bp = posvec_bp(snpInds);
  chr       = chr(snpInds);
  G         = genomats(:,snpInds);
  clear genomats;
  
  mafvec = (sum(G,1) + sum(G==-1,1))./(2*sum(G~=-1,1));        % min 0.001988071570577;  max 0.5.
  %mafvec = mean(G,1)/2;  % Can't use this because of the -1s. %'
  if max(mafvec) > 0.5,  keyboard;  end
  mafvec(mafvec>0.5) = 1-mafvec(mafvec>0.5);    % <---------------
  
  if 0
  indxFirst10 = find(strcmp(chr,'10'),1);  %  Els of chr are '1',...'9','10',...'22'. Transitioning from '9' to '10' causes cell2mat to go nuts.
  
  % OK for autosomal (1-22). Not OK for X and Y!!
  chr1_int8=int8(str2num(cell2mat(chr(1:indxFirst10-1))));
  chr2_int8=int8(str2num(cell2mat(chr(indxFirst10:end))));
  chr = cat(1,chr1_int8,chr2_int8);  % 14.9 MB.
  clear chr1_int8 chr2_int8;
  end  % if 0
  
  tic
  fullFileName = [outDir '/snpidlist.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'snpidlist');
  fprintf(1,'done.\n');
  toc
  
  fullFileName = [outDir '/snpInds.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'snpInds');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/posvec_cM.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'posvec_cM');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/posvec_bp.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'posvec_bp');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/chr.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'chr');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/G.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'G','-v7.3');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/mafvec.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'mafvec');
  fprintf(1,'done.\n');
  mafvecSingle = single(mafvec);
else
  fprintf(1,'Reading %s...',C_fullFileName);
  load(C_fullFileName);
  fprintf(1,'done.\n');
  fprintf(1,'Reading %s...',G_fullFileName);              % File is  MB;  genomatUseful is  GB.
  load(G_fullFileName);                                   % G is 503X14933168
  fprintf(1,'done.\n');
  mafvec = (sum(G,1) + sum(G==-1,1))./(2*sum(G~=-1,1));   % min 0.001988071570577;  max 0.5.
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% See ~/matlab/SynGP/buildLDhistAndTLD_HapGen_A.m:
% Restrict G to the 11M SNPs that are in HapGen and for which less than 1 percent of subjects have genotype==0
if RESTRICT_TO_HAPGEN_1PC
  inDirAlt = '/space/md10/8/data/holland/genetics/LDhistAndTLD_1kGPhase3_hg19';
  fullFileName_RemappingIndices = [inDirAlt '/1kGPIII14p9m_n_HG1pc_Indices.mat'];
  fprintf(1,'Reading %s...',fullFileName_RemappingIndices);
  load(fullFileName_RemappingIndices, 'i1kGPIII14p9m_1kGPIII14p9m_n_HG1pc', 'i1kGPIII14p9m_HG1pc_n_1kGPIII14p9m');  % Same order?
  fprintf(1,'done.\n');
  
  G      = G     (:,i1kGPIII14p9m_1kGPIII14p9m_n_HG1pc);  % 503x11015833
  mafvec = mafvec(  i1kGPIII14p9m_1kGPIII14p9m_n_HG1pc);  % 11015833
  chr    = chr   (  i1kGPIII14p9m_1kGPIII14p9m_n_HG1pc);  % 11015833
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~RESTRICT_TO_HAPGEN_1PC, keyboard;  end % Don''t have an lvec that is 14m....

%xx = load('/space/md10/8/data/holland/genetics/LDhistAndTLD_1kGPhase3_hg19/TLDr2_BlockExt_25000_1kGHG1pc_zontr2_p1.mat'); % THIS is built here; see also causalEffectsModelDriver11m.m 
%lvec = xx.tldvec; clear xx;
L_fullFileName = '/space/md10/8/data/holland/genetics/LDhistAndTLD_1kGPhase3_hg19/tldvec_builtFrom_LDr2hist.mat';
fprintf(1,'Reading %s...',L_fullFileName);
load(L_fullFileName); % tldvec_builtFrom_LDr2hist; see causalEffectsModelDriver11m.m 
fprintf(1,'done.\n');
lvec = tldvec_builtFrom_LDr2hist; % 11015833

if EXCLUDE_EVERY_OTHER_SNP
  nsubj = size(G,1);  % 503;      Eli 1kGPhase1: 379
  nsnps = size(G,2);  % 11015833; Eli 1kGPhase1: 9423850
  indsLogical = true(nsnps,1);
  inds = find(indsLogical);
  indsLogical = logical(mod(inds,2));
  G = G(:,indsLogical);  % 503x5507917
  mafvec = mafvec(indsLogical);
  lvec = lvec(indsLogical);
  chr = chr(indsLogical);
  clear indsLogical inds;
end

hvec = 2*mafvec.*(1-mafvec);

nsubj = size(G,1);  % 503;      Eli 1kGPhase1: 379
nsnps = size(G,2);  % 11015833; Eli 1kGPhase1: 9423850

W = single(G);      %
W(W==-1) = NaN;                % 28365 SNPs have NaN for at least one subject.
Wlogical = isfinite(W);
sumSubjs_vec=sum(Wlogical,1);
snpsWithAllSubjsLogical = sumSubjs_vec==nsubj;
snpsWithAllSubjs = find(snpsWithAllSubjsLogical);
numSNPsWithAllSubjs = length(snpsWithAllSubjs);  % 14858804  ==> 74364 SNPs do not have complete data (up to 10 percent of subjects missing for these SNPs).

clear G sumSubjs_vec;

% REPLACE MISSING DATA WITH MEAN
for i=1:nsnps
  W(~Wlogical(:,i),i) = 2*mafvec(i);  % This leads to a slight inaccuracy in the LD estimated involving a SNP missing some subjects.
end
clear Wlogical;

ldr2binsNum = 100;  %  50?
ldrbinsNum  = 200;  % 100?
ldr2binsEdges = linspace( 0,1,ldr2binsNum+1);
ldrbinsEdges  = linspace(-1,1,ldrbinsNum +1);
ldr2binsCenters = nan(1,ldr2binsNum); for i=1:ldr2binsNum, ldr2binsCenters(i) = (ldr2binsEdges(i+1)+ldr2binsEdges(i))/2; end
ldrbinsCenters  = nan(1,ldrbinsNum);  for i=1:ldrbinsNum,  ldrbinsCenters(i)  = (ldrbinsEdges(i+1) +ldrbinsEdges(i))/2; end

numSNPsChriVec     = nan(22,1);
blockWidth         =  5000;
 blockExtension     = 25000;  % Mostly have used 50000. Try 25000? NOTE: Output files without blockExtension in their name have used 50000.
%blockExtension     = 50000;  % Mostly have used 50000. Try 25000? NOTE: Output files without blockExtension in their name have used 50000.
cumulativeSNPCount = 0;

numBlocksGrandTotal = ceil(nsnps/blockWidth);

tldvec   = nan(nsnps,1);
%LDr2hist = 0;  % REMOVE!
%if 0 % REMOVE!
LDr2hist = zeros(nsnps,ldr2binsNum);
Hhist    =   nan(nsnps,ldr2binsNum);
%end % REMOVE!
Lhist    =   nan(nsnps,ldr2binsNum);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if 0 % 1kG Phase 1 BIP
snpsOfInterest = {...
    'chr2_97376407_I',...
    'chr15_85357857_I',...
    'rs12226877',...
    'chr2_194465711_D',...
    'chr10_111745562_I'};
snpsOfInterest = snpsOfInterest'; %'
nsoi = length(snpsOfInterest);

[SOIlist soi_ia soi_ib] = intersect(snpidlist, snpsOfInterest, 'stable');
chrvecSOI =    chr(soi_ia);
mafvecSOI = mafvec(soi_ia);
hvecSOI   =   hvec(soi_ia);

LDr2histSOI = zeros(nsoi,ldr2binsNum);
HhistSOI    =   nan(nsoi,ldr2binsNum);
for i=1:nsoi
   indSOI = soi_ia(i);
   chri = chr(indSOI);
   find(chr==chri,1);
   chrIndFirst = find(chr==chri,1);
   chrIndLast  = find(chr==chri,1,'last');
   ldwinLwrInd = max(indSOI-25000,chrIndFirst);
   ldwinUprInd = min(indSOI+25000,chrIndLast);
   snpsvec1 = [ldwinLwrInd:ldwinUprInd];
   snpsvec2 = indSOI;
   nsnpsj1  = length(snpsvec1);
   nsnpsj2  = 1;
   
   %for j=1:nsnpsj1
   %  rmat(j) = corr(W(:,snpsvec1(j)),W(:,indSOI));  % rmat1(25001) is correlation with indSOI with self, i.e., 1.
   %end
   
   rmat = corr(W(:,snpsvec1),W(:,indSOI));  % rmat1(25001) is correlation with indSOI with self, i.e., 1.
   rmat(isnan(rmat)) = 0; % E.g., is a SNP has all 1''s (which also means that maf=0.5 and H=0.5) then it''s correlation with any other SNP will be nan.
                          % Such SNPs should be weeded out.
   r2mat = rmat.^2;
   [Hvals Cntvals] = histmean_dh(r2mat, hvec(snpsvec1), ldr2binsCenters);
   LDr2histSOI(i,:) = Cntvals;
   HhistSOI(i,:)    = Hvals;    % Hvals will have NaN where Cntvals is 0.
   if ZERO_OUT_NOISE,  r2mat(r2mat<noiseThreshold_r2) = 0;  end
   tldvec(indSOI) = sum(r2mat);
end
tldvecSOI = tldvec(soi_ia);

fullFileName = [outDir '/SOI.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'SOIlist', 'chrvecSOI', 'mafvecSOI', 'hvecSOI','LDr2histSOI','HhistSOI','tldvecSOI','soi_ia','soi_ib');
fprintf(1,'done.\n');

keyboard
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

beginningOfTime = now;
for chri = 1:22
  chriInds  = find(chr == chri);
  nsnpsChri = length(chriInds);
  
  blockNum = 0;
  numBlocks = ceil(nsnpsChri/blockWidth);
  
  for blocki = 1:blockWidth:nsnpsChri
    blockNum   = blockNum + 1;
    blockStart = cumulativeSNPCount+blocki;
    blockEnd   = cumulativeSNPCount+min(nsnpsChri,blocki+blockWidth-1);
    
    isearchStart = cumulativeSNPCount+max(1,blocki-blockExtension);
    isearchEnd   = cumulativeSNPCount+min(nsnpsChri,blocki+blockWidth-1+blockExtension);
    
    snpsvec1 = [blockStart:blockEnd];
    snpsvec2 = [isearchStart:isearchEnd];
    nsnpsj1  = length(snpsvec1);
    nsnpsj2  = length(snpsvec2);
    
    rmat = corr(W(:,snpsvec1),W(:,snpsvec2));     % NOTE: If W has NaN (not -1) for missing data, then correlation between any pair of SNPs for which there is at least one NaN will be NaN.
    r2mat = rmat.^2;
   %if ZERO_OUT_NOISE,  r2mat(r2mat<noiseThreshold_r2) = 0;  end
    
    numBlocksCompleted = ceil(blockEnd/blockWidth);
    
   %rmat1  = corr(W(:,snpsvec1),W(:,snpsvec1));
   %r2mat1 = rmat1.^2;
   %figure(1); clf; imagesc(rmat1);  colormap(blueblackred); colorbar; axis equal; axis tight; drawnow;
   %figure(2); clf; imagesc(r2mat1); colormap(blueblackred); colorbar; axis equal; axis tight; drawnow;
    
   %tldvec(snpsvec1) = sum(r2mat,2);
    
    time0 = now;
    for k=1:nsnpsj1
     %hldr2 = hist(r2mat(k,:),ldr2binsCenters);
     %snpj = snpsvec1(k);
     %LDr2hist(snpj,:) = hldr2;
      
      [Hvals Cntvals] = histmean_dh(r2mat(k,:), hvec(snpsvec2), ldr2binsCenters);
      [Lvals Cntvals] = histmean_dh(r2mat(k,:), lvec(snpsvec2), ldr2binsCenters); % Using lvec = tldvec_builtFrom_LDr2hist; see causalEffectsModelDriver11m.m;
      
      LDr2hist(snpsvec1(k),:) = Cntvals;  % SAME as:  LDr2hist(snpsvec1(k),:) = hist(r2mat(k,:),ldr2binsCenters);
      Hhist(snpsvec1(k),:)    = Hvals;    % Hvals will have NaN where Cntvals is 0.
      Lhist(snpsvec1(k),:)    = Lvals;    % Lvals will have NaN where Cntvals is 0.
      
     %if ~mod(k,1e3) | k==nsnpsj1
     %  s1 = datestr(now,'dddd HH:MM:SS');
     %  s2 = datestr(time0+(now-time0)*nsnpsj1/k,'dddd HH:MM:SS');
     %  fprintf(1,['chr %d  block %d of %d (%d of %d): k=%d of %d  (now=%s done=%s)\r\b'],...
     %            chri,blockNum,numBlocks,numBlocksCompleted,numBlocksGrandTotal,k,nsnpsj1,s1,s2);
     %end
    end
    
    % Keep "noise" for LDr2hist -- can control later by ignoring lower r^2 bins.
    % But, eliminate "noise" for tld estimate.... Of course, tld can also be estimated from LDr2hist.
    if ZERO_OUT_NOISE,  r2mat(r2mat<noiseThreshold_r2) = 0;  end
    tldvec(snpsvec1) = sum(r2mat,2);
    
    s1 = datestr(now,'dddd HH:MM:SS');
    s2 = datestr(beginningOfTime+(now-beginningOfTime)*numBlocksGrandTotal/numBlocksCompleted,'dddd HH:MM:SS');
    fprintf(1,['chr %d  block %d of %d (%d of %d): (now=%s done=%s)\r\b'],...
               chri,blockNum,numBlocks,numBlocksCompleted,numBlocksGrandTotal,s1,s2);
  end
  
  numSNPsChriVec(chri) = nsnpsChri;
  cumulativeSNPCount = cumulativeSNPCount + nsnpsChri;
end

fileNameInfix = [];
fileNameInfix = ['_BlockExt_' num2str(blockExtension)];

if RESTRICT_TO_HAPGEN_1PC,  fileNameInfix = [fileNameInfix '_1kGHG1pc'];  end
if EXCLUDE_EVERY_OTHER_SNP, fileNameInfix = [fileNameInfix '_half'];  end

fullFileName = [outDir '/Hhist' fileNameInfix '.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'Hhist', '-v7.3');
fprintf(1,'done.\n');

fullFileName = [outDir '/Lhist' fileNameInfix '.mat']; % Histogram giving total LDs
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'Lhist', '-v7.3');
fprintf(1,'done.\n');

fullFileName = [outDir '/LDr2hist' fileNameInfix '.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'LDr2hist', '-v7.3');
fprintf(1,'done.\n');

if ZERO_OUT_NOISE, fileNameInfix = [fileNameInfix '_zontr2_p' num2str(100*noiseThreshold_r2)];  end

fullFileName = [outDir '/TLDr2' fileNameInfix '.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'tldvec', '-v7.3');
fprintf(1,'done.\n');
