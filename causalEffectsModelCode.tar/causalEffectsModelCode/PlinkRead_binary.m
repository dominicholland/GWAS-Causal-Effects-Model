function [chrvec, snplist, A1vec, A2vec, cMvec, bpvec, FID, IID, sexvec, phenovec, genomat] = PlinkRead_binary(fileprefix)

% This function is to read in the plink binary bed file
% Modified from python code: pyplink - Copyright (c) 2014 Louis-Philippe Lemieux Perreault
% Basic idea is to read in the binary quickly and then process accordingly
% The time limiting step would still be individual fam and bim file
%
% Chun Chieh Fan July 2015

% global parameters:
tic;
geno_code = [  -1, ... % missing data
		1, ... % heterozygous
		0, ... % homozygous A2
		2, ... % homozygous A1
		];

% bit shift to generate the genovalue matrix
bedprefix = [fileprefix,'.bed'];
fprintf('Loading plink bed from %s ', bedprefix);
geno_values = int8(zeros(256,4));
shiftind = [0,2,4,6];
for i = 1:256;
	ishift = int16(i-1);
	for j = 1:4;
		indvec(j) = bitand(bitsra(ishift,shiftind(j)),3) ;
	end
	indvec(indvec == 0) = 4;
	geno_values(i,:) = geno_code(indvec);
end

% Read in the binary file
bedid = fopen(bedprefix);
genobin = uint16(fread(bedid));
fclose(bedid);

% Check magic number
if genobin(1) ~= 108;
	error('- Not a valid Plink BED file \r\n');
elseif genobin(2) ~= 27;
	error('- Not a valid Plink BED file \r\n');
elseif genobin(3) ~= 1;
	error('- Not in SNP-major format \r\n');
end
fprintf(' - Done Checking \r\n');

% Get the fam
famprefix = [fileprefix,'.fam'];
fprintf('Read in plink fam from %s \r\n', famprefix);
famid = fopen(famprefix,'r');
famdata = textscan(famid, '%s %s %d %d %d %d');
fclose(famid);
% check header
if strcmp(famdata{1}(1),'FID');
	FID = famdata{1}(2:end);
	IID = famdata{2}(2:end);
	sexvec = famdata{5}(2:end);
	phenovec = famdata{6}(2:end);	
else
	FID = famdata{1};
	IID = famdata{2};
	sexvec = famdata{5};
	phenovec = famdata{6};	
end

nsubj = length(FID);

n_bytes = ceil(nsubj/4);


% Get the bim
bimprefix = [fileprefix,'.bim'];
fprintf('Read in plink bim from %s \r\n', bimprefix);
bimid = fopen(bimprefix,'r');
bimdata = textscan(bimid, '%s %s %d %d %s %s');
fclose(bimid);
chrvec = bimdata{1};
%chrvec = int8(str2num(cell2mat(chrvec)));
snplist = bimdata{2};
cMvec = bimdata{3};
bpvec = bimdata{4};
A1vec = bimdata{5};
A2vec = bimdata{6};

nsnp = length(snplist);

% reshape the genomat
fprintf('Transforming the genomat .... \r\n');
if length(genobin) ~= 3 + n_bytes*nsnp;
       error('-- Invalid number of entries from the bed \r\n');
end
genomat = int8(zeros(nsubj,nsnp));
for i = 1:nsnp;
	tmp_values = reshape(geno_values(genobin(4+(i-1)*n_bytes:4+i*n_bytes-1) + 1,:).',[],1);
	genomat(:,i) = tmp_values(1:nsubj);
end
t = toc;
fprintf(' -- Done! -- elapsed time: %f secs \r\n', t);




