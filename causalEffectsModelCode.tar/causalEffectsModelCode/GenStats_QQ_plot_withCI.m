
% Dominic Holland
% https://www.biorxiv.org/content/early/2018/06/07/133132

function [logqmat hv_logp logqmat_ci] = GenStats_QQ_plot_withCI(logpmat,hv_z,ci_alpha,f,phenoName)

% f is the number of SNPs that are represented, on average, by each SNP.
% n is he total number of SNPs, so n/f is the expected number of independent SNPs.

 PLOT_NORMAL_APPROX_CI = false;
%PLOT_NORMAL_APPROX_CI = true;

if exist('hv_z','var') & ~isempty(hv_z)
  hv_logp = -log10(2*normcdf(-abs(hv_z)));
else
  hv_logp = linspace(0,200,10000);
end

if exist('ci_alpha','var') & isempty(ci_alpha), ci_alpha = 0.05; end
if ~exist('f','var') | (exist('f','var') & isempty(f)),  f = 1.0;  end
if ~exist('phenoName','var'),  phenoName  = '';    end

for j = 1:size(logpmat,2)
  logpvec = logpmat(:,j);
  hc = hist(logpvec,hv_logp);
  chc = cumsum(hc)/sum(hc);
  if j==1, logqmat = NaN(length(chc),size(logpmat,2)); logqmat_ci = NaN(length(chc),size(logpmat,2),2); end
 %logqmat(:,j) = -log10(1-chc);
  shc = sum(hc);
  prop = zeros(size(hv_z));
  prop(1) = 1;
  prop(2:end) = (shc-cumsum(hc(1:end-1)))/shc;  % See below.
  logqmat(:,j) = -log10(prop);
  if exist('ci_alpha','var')
    [phat pci] = binofit(round(cumsum(hc)/f),round(sum(hc)*ones(size(hc))/f),ci_alpha); % Compute confidence interval, assuming independence (no LD);  pci is the Cloper-Pearson "exact" CI.
    
    logicalInds2_unity    = pci(:,2)==1;
    logicalInds2_notUnity = ~logicalInds2_unity;
    inds2_unity = find(logicalInds2_unity);
    tmp = max(pci(~logicalInds2_unity,2));
    
    qq_ci1Tmp = -log10(1-pci(:,1));
    qq_ci2Tmp = -log10(1-pci(:,2));
    
    indSpecial = max(find(logicalInds2_notUnity));
    
    d1 =   logqmat(indSpecial+1) - qq_ci1Tmp(indSpecial+1);
    d2 = -(logqmat(indSpecial)   - qq_ci2Tmp(indSpecial));
    
    symmetricShift = logqmat(indSpecial+1:end) - qq_ci1Tmp(indSpecial+1:end);
    qq_ci2Tmp(indSpecial+1:end) = logqmat(indSpecial+1:end) + symmetricShift + (d2-d1);
    
    qq_ci1 = zeros(size(qq_ci1Tmp));
    qq_ci2 = zeros(size(qq_ci2Tmp));
    qq_ci1(1) = 0;  qq_ci1(2:end) = qq_ci1Tmp(1:end-1);
    qq_ci2(1) = 0;  qq_ci2(2:end) = qq_ci2Tmp(1:end-1);
    logqmat_ci(:,j,1) = qq_ci1;
    logqmat_ci(:,j,2) = qq_ci2;
    
    indMax = find(isfinite(logqmat(:,j)), 1, 'last');
    logqmat_ci(indMax+1:end,j,1) = nan;
    logqmat_ci(indMax+1:end,j,2) = nan;

    if PLOT_NORMAL_APPROX_CI
      q = prop;
      ntot = sum(hc);
      neff = ntot/f;
      q_CI_Normal_upr = q + abs(norminv(0.025)).*sqrt(q.*(1-q)/neff);   % norminv(0.025) = -1.9600;
      q_CI_Normal_lwr = q - abs(norminv(0.025)).*sqrt(q.*(1-q)/neff);
      q_CI_Normal_lwr(q_CI_Normal_lwr<=0) = nan;
      logq_CI_Normal_upr = -log10(q_CI_Normal_upr);
      logq_CI_Normal_lwr = -log10(q_CI_Normal_lwr);
    end
  end
end
if nargout==0
  xlimUpr = 9;
  ylimUpr = 16;
  plot([0 xlimUpr],[0 xlimUpr],'k:',logqmat,hv_logp,'LineWidth',2); xlim([0 xlimUpr]); ylim([0 ylimUpr]); h=xlabel('Empirical -log_1_0(q)'); set(h,'FontSize',20); h=ylabel('Nominal -log_1_0(p)'); set(h,'FontSize',20); hold on;
  if exist('ci_alpha','var')
    plot(logqmat_ci(:,1),hv_logp,'g',logqmat_ci(:,2),hv_logp,'g','LineWidth',2); xlim([0 xlimUpr]); ylim([0 ylimUpr]); h=xlabel('Empirical -log_1_0(q)'); set(h,'FontSize',20); h=ylabel('Nominal -log_1_0(p)'); set(h,'FontSize',20); hold on;
    if PLOT_NORMAL_APPROX_CI
      plot(logq_CI_Normal_lwr,hv_logp,'r',logq_CI_Normal_upr,hv_logp,'b','LineWidth',2); xlim([0 xlimUpr]); ylim([0 ylimUpr]); h=xlabel('Empirical -log_1_0(q)'); set(h,'FontSize',20); h=ylabel('Nominal -log_1_0(p)'); set(h,'FontSize',20); hold on;
    end
  end
  if length(phenoName)
    ht=title(phenoName); set(ht,'FontSize',22);  % This needs to come after plot(). Who knew?
  end
end
