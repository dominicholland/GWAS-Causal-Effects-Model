

% Dominic Holland
% https://www.biorxiv.org/content/early/2018/06/07/133132

% causalEffectsModelDriver

function causalEffectsModelDriver(pheno,minr2)
% causalEffectsModelDriver('bip',0.05)
if ~exist('pheno','var'), pheno = 'scz'; end
if ~exist('minr2','var'), minr2 = 0.05;  end
pheno
minr2

USE50k = false;  % Use 25k instead
PRODUCTION = true;
 
AD_INCLUDE_CHR_19_ONLY = false;
AD_EXCLUDE_CHR_19 = false;
AD_EXCLUDE_CHRs_6_11_19 = false;
EXCLUDE_APOE = false;
ESTIMATE_TLD_MAX_AND_LD_BLOCK_SIZE_MAX = true;
RESTRICT_TO_9m = false;
DO_ALEX = false;
USE_14M = false;
NONRANDOM_PRUNE = false;
RANDOM_PRUNE    = true;
PRUNE = false;
if (RANDOM_PRUNE | NONRANDOM_PRUNE),  PRUNE = true;  end  
USE_R2MAT = false;
RESTRICT_TO_SCZ_5m = false;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pick ONE of these three:
EQUAL_SIZE_HLB_BINS = true;
FIXED_PERCENTILE_HLB_BINS = false;
VARIABLE_PERCENTILE_HLB_BINS = false;

if EQUAL_SIZE_HLB_BINS + FIXED_PERCENTILE_HLB_BINS + VARIABLE_PERCENTILE_HLB_BINS > 1,  keyboard;  end
if EQUAL_SIZE_HLB_BINS + FIXED_PERCENTILE_HLB_BINS + VARIABLE_PERCENTILE_HLB_BINS ==0,  keyboard;  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DO_META = false;

DO_SCZ_SEP2017 = false;
DO_SCZ     = false;
DO_BIP     = false;
DO_CAD     = false;    % coronary artery disease  http://www.cardiogramplusc4d.org/data-downloads/
DO_PUTAMEN   = false;
DO_ACCUMBENS = false;
DO_AMYGDALA  = false;
DO_CAUDATE   = false;
DO_HIPPO     = false;
DO_ICV_Enigma2  = false;
DO_PALLIDUM  = false;
DO_THALAMUS  = false;
DO_MDD       = false;
DO_MDD2018   = false;
DO_HEIGHT    = false;     % 2014 Wood et al.
DO_HEIGHT2010   = false;
DO_HEIGHT2018   = false;
DO_EXTRAVERSION = false;
DO_NEUROTICISM  = false;
DO_OPENNESS     = false;
DO_SBP = false;
DO_BMI = false;
DO_CRP = false;
DO_HDL = false;
DO_LDL = false;
DO_TC  = false;
DO_TG  = false;
DO_IQ  = false;
DO_ReactionTime = false;
DO_COG          = false;
DO_COG2018      = false;
DO_VNR          = false;
DO_EduYear      = false;
DO_AD      = false;     % No APOE
DO_AD2018  = false;     % APOE filtered out below.
DO_CA  = false;
DO_CO  = false;
DO_UC  = false;
DO_CD  = false;

if     strcmp(pheno,'scz'),  DO_SCZ =     true;
elseif strcmp(pheno,'sczSep2017'),  DO_SCZ_SEP2017 =     true;
elseif strcmp(pheno,'bip'),  DO_BIP =     true;
elseif strcmp(pheno,'cad'),  DO_CAD =     true;
elseif strcmp(pheno,'putamen'),     DO_PUTAMEN = true;
elseif strcmp(pheno,'accumbens'),   DO_ACCUMBENS  = true;
elseif strcmp(pheno,'amygdala'),    DO_AMYGDALA   = true;
elseif strcmp(pheno,'caudate'),     DO_CAUDATE    = true;
elseif strcmp(pheno,'hippo'),       DO_HIPPO      = true;
elseif strcmp(pheno,'icv')     ,    DO_ICV_Enigma2= true;
elseif strcmp(pheno,'pallidum'),    DO_PALLIDUM   = true;
elseif strcmp(pheno,'thalamus'),    DO_THALAMUS   = true;
elseif strcmp(pheno,'mdd'),         DO_MDD        = true;
elseif strcmp(pheno,'mdd2018'),     DO_MDD2018    = true;
elseif strcmp(pheno,'height'),      DO_HEIGHT     = true;  % 2014 Wood et al
elseif strcmp(pheno,'height2010'),  DO_HEIGHT2010 = true;
elseif strcmp(pheno,'height2018'),  DO_HEIGHT2018 = true;
elseif strcmp(pheno,'extraversion'),  DO_EXTRAVERSION = true;
elseif strcmp(pheno,'neuroticism'),   DO_NEUROTICISM  = true;
elseif strcmp(pheno,'openness'),      DO_OPENNESS     = true;
elseif strcmp(pheno,'bmi'),  DO_BMI = true;
elseif strcmp(pheno,'crp'),  DO_CRP = true;
elseif strcmp(pheno,'hdl'),  DO_HDL = true;
elseif strcmp(pheno,'ldl'),  DO_LDL = true;
elseif strcmp(pheno,'tc'),   DO_TC  = true;
elseif strcmp(pheno,'tg'),   DO_TG  = true;
elseif strcmp(pheno,'ReactionTime'),   DO_ReactionTime  = true;
elseif strcmp(pheno,'cog'),   DO_COG  = true;
elseif strcmp(pheno,'cog2018'),   DO_COG2018  = true;
elseif strcmp(pheno,'vnr'),   DO_VNR  = true;
elseif strcmp(pheno,'edu'),   DO_EduYear  = true;
elseif strcmp(pheno,'ad'),    DO_AD  = true;         % No APOE
elseif strcmp(pheno,'ad2018'),    DO_AD2018  = true; % APOE filtered out below
elseif strcmp(pheno,'cogentAll'),    DO_CA  = true;
elseif strcmp(pheno,'cogentOnly'),   DO_CO  = true;
elseif strcmp(pheno,'iq'),    DO_IQ  = true;
elseif strcmp(pheno,'uc'),    DO_UC  = true;
elseif strcmp(pheno,'cd'),    DO_CD  = true;
%elseif strcmp(pheno,'sbp'),  DO_SBP = true;
else   keyboard;  end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limit fit to region of QQ plot defined by range from qq_ymin to qq_ymax on y-axis...

fileName = '/space/md10/8/data/holland/genetics/LDhistAndTLD_1kGPhase3_hg19/chrvec_1kGPIII14p9m_n_HG1pc.mat';
load(fileName);  % chr 11015833x1              11015833  int8

nonlin_z_bins_minimization=false;
nq = 128;
qq_y_uprTmp1 = 0;
qq_y_uprTmp2 = -log10(2*normcdf(-38));   % == 315.2388  <---> z = 38 (2-sided)

qq_ymin = 0.0;
if DO_SCZ
  qq_ymin =  0.0;
  qq_ymax = 20.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 25
  TLD_MAX =  600;
elseif DO_SCZ_SEP2017
  qq_ymin =  0.0;  %  0.0
  qq_ymax = 20.0;  % 20.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 20
  TLD_MAX =  600;
elseif DO_BIP
  qq_ymin =  0.0;
  qq_ymax = 20.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 25
  TLD_MAX =  600;
elseif DO_CAD
  qq_ymin =   1.0;
  qq_ymax = 100.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 20
  TLD_MAX =  600;
elseif DO_PUTAMEN
  nonlin_z_bins_minimization=true;
  nq = 128;
  qq_ymin =  0.0;
  qq_ymax = 21.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax =  10
  TLD_MAX =  600;
elseif DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO | DO_PALLIDUM | DO_THALAMUS
  qq_ymin =  1.5;
  qq_ymax = 21.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax =  20
  TLD_MAX =  600;
elseif DO_ICV_Enigma2
  qq_ymin = 0.0;
  qq_ymax = 12.0;
  nCausalsPerBlockMax = 12
  LD_BLOCK_SIZE_MAX =  20000;
  TLD_MAX           =  99999;
elseif DO_MDD |  DO_MDD2018
  qq_ymin = 0.0;
  qq_ymax = 7.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 100
  TLD_MAX =  600;
elseif DO_HEIGHT
  nq = 128;
  qq_ymin =   0.0;
  qq_ymax =150.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 16  % 12
  TLD_MAX =  600;
elseif DO_HEIGHT2010
  nq = 128;
  qq_ymin =   0.0;
  qq_ymax = 45.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 16
  TLD_MAX =  600;
elseif DO_HEIGHT2018
  nq = 128;
  qq_ymin =   0.0;
  qq_ymax =275.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 16
  TLD_MAX =  600;
elseif DO_EXTRAVERSION
  qq_ymin = 0.0;
  qq_ymax = 20.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 50
  TLD_MAX =  600;
elseif DO_NEUROTICISM
  qq_ymin = 0.0;
  qq_ymax = 12.0;
  nCausalsPerBlockMax = 40
  LD_BLOCK_SIZE_MAX = 20000;
  TLD_MAX           = 99999;
elseif DO_OPENNESS
  qq_ymin = 0.0;
  qq_ymax =12.0;
  nCausalsPerBlockMax = 60
  LD_BLOCK_SIZE_MAX = 20000;
  TLD_MAX           =  1000;
elseif  DO_CRP
  qq_ymin = 0.0;
  qq_ymax = 220.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 12
  TLD_MAX =  600;
elseif DO_HDL
  qq_ymin = 0.0;
  qq_ymax = 320.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 12
  TLD_MAX =  600;
elseif DO_TC | DO_TG | DO_LDL | DO_UC
  qq_ymin = 0.0;
  qq_ymax = 320.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 12
  TLD_MAX =  600;
elseif DO_CD
  qq_ymin =  0.0;
  qq_ymax = 320.0;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 20
  TLD_MAX =  600;
elseif DO_BMI
  qq_ymin = 0.0;
  qq_ymax = 320.0;
  nonlin_z_bins_minimization=true;
  LD_BLOCK_SIZE_MAX = 2000;
  nCausalsPerBlockMax = 12
  TLD_MAX =  600;
elseif  DO_EduYear
  qq_ymin = 0.0;
  qq_ymax = 30.0;
  nCausalsPerBlockMax = 25
  LD_BLOCK_SIZE_MAX =  2000;
  TLD_MAX           =   600;
elseif  DO_ReactionTime | DO_VNR | DO_CA | DO_CO
  qq_ymin = 0.0;
  qq_ymax = 12.0;
  nCausalsPerBlockMax = 30
  LD_BLOCK_SIZE_MAX = 1500;
  TLD_MAX           =  600;
elseif  DO_AD | DO_AD2018
  qq_ymin = 0.0;   %  0.0
  qq_ymax = 100.0;   % 16
  
  if AD_EXCLUDE_CHR_19,  qq_ymax = 20;   end
  
  nCausalsPerBlockMax = 20
  LD_BLOCK_SIZE_MAX = 2000;
  TLD_MAX           =  600;
elseif  DO_COG | DO_COG2018 | DO_CTG_INTELLIGENCE_2018
  qq_ymin = 0.0;    %  0.0
  qq_ymax = 200.0;   % 16
  nCausalsPerBlockMax = 30
  LD_BLOCK_SIZE_MAX = 2000;
  TLD_MAX           =  600;
elseif  DO_IQ
  qq_ymin = 0.0;   %  0.0
  qq_ymax = 200.0;   % 16
  nCausalsPerBlockMax = 20
  LD_BLOCK_SIZE_MAX = 2000;
  TLD_MAX           =  600;
else keyboard;  end

minr2
qq_ymin
qq_ymax

if PRODUCTION
  nrep   = 10;
  nHbins = 10;
  nLbins = 10;
  nBbins =  1;
else
  nrep   =  1
  nHbins =  4;
  nLbins =  4;
  nBbins =  1;
end

nr2binsNew = 18;
if minr2==0.01,   nr2binsNew = 19;  end;  nr2binsNew

qq_pylwr = 10^-qq_ymin;   % qq_ymin = -log10(qq_pylwr);
qq_y_zmin = -norminv(qq_pylwr/2);

qq_pyupr = 10^-qq_ymax;   % qq_ymax = -log10(qq_pyupr);
qq_y_zmax = -norminv(qq_pyupr/2);

% --> qq_ymax = -log10(2*normcdf(-qq_y_zmax))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if USE50k
 outDir = ['/space/md10/8/data/holland/genetics/11mPhenos_minr2_p0' num2str(round(100*minr2)) '_H' num2str(int32(nHbins)) '_L' num2str(int32(nLbins)) '_R' num2str(int32(nrep)) '_NewBeff_50k'];
else
 outDir = ['/space/md10/8/data/holland/genetics/11mPhenos_minr2_p0' num2str(round(100*minr2)) '_H' num2str(int32(nHbins)) '_L' num2str(int32(nLbins)) '_R' num2str(int32(nrep)) '_NewBeff_BIP2'];
end

if ~exist( outDir, 'dir'),  mkdir(outDir);  end;
outDir
inDir = '/space/md10/8/data/holland/genetics/LDhistAndTLD_1kGPhase3_hg19';
if ~exist(inDir, 'dir')
  fprintf(1, 'inDir %s does not exist.\n', inDir);
  keyboard;
end;

if USE_14M
 filename = [inDir '/LDr2hist_zontr2_p5.mat'];  % Bit of a misnomer here: this file is for zeroing out "noise" at r^2<0.05 SEE buildLDhistAndTLD_A.m
else  % 11M
 if USE50k
  filename = [inDir '/LDr2hist_BlockExt_50000_1kGHG1pc.mat']; % SEE buildLDhistAndTLD_A.m    % LDr2hist 11015833x100
 else
  filename = [inDir '/LDr2hist_BlockExt_25000_1kGHG1pc.mat']; % SEE buildLDhistAndTLD_A.m    % LDr2hist 11015833x100
 end
end
load(filename);

if AD_INCLUDE_CHR_19_ONLY
  LDr2hist = LDr2hist(chr==19,:);
elseif AD_EXCLUDE_CHR_19
  LDr2hist = LDr2hist(chr~=19,:);
end

if USE_14M
  keyboard; % not implemented for new beta_eff.
else
 if USE50k
  filename= [inDir '/Hhist_BlockExt_50000_1kGHG1pc.mat'];    % SEE buildLDhistAndTLD_A.m    % Hhist    11015833x100
 else
  filename= [inDir '/Hhist_BlockExt_25000_1kGHG1pc.mat'];    % SEE buildLDhistAndTLD_A.m    % Hhist    11015833x100
 end
end
load(filename);
if AD_INCLUDE_CHR_19_ONLY
  Hhist = Hhist(chr==19,:);
elseif AD_EXCLUDE_CHR_19
  Hhist = Hhist(chr~=19,:);
end

if USE_14M
 filename = [inDir '/TLDr2_zontr2_p5.mat'];     % Bit of a misnomer here: this file is for zeroing out "noise" at r^2<0.05  SEE buildLDhistAndTLD_A.m
else  % 11M  SEE buildLDhistAndTLD_A.m
 if USE50k
  filename = [inDir '/TLDr2_BlockExt_50000_1kGHG1pc_zontr2_p1.mat']; % OPTIONALLY, USE THIS. SEE buildLDhistAndTLD_A.m
 else
  filename = [inDir '/TLDr2_BlockExt_25000_1kGHG1pc_zontr2_p1.mat']; % OPTIONALLY, USE THIS. SEE buildLDhistAndTLD_A.m
 end
 
end
load(filename);  % tldvec
if AD_INCLUDE_CHR_19_ONLY
  tldvec = tldvec(chr==19);
elseif AD_EXCLUDE_CHR_19
  tldvec = tldvec(chr~=19);
end

if USE_14M
 fullFileName = [inDir '/mafvec.mat'];
else  % 11M
 fullFileName = [inDir '/mafvec_1kGPIII14p9m_n_HG1pc.mat'];  % 1x11015833 single
end
load(fullFileName, 'mafvec');

if AD_INCLUDE_CHR_19_ONLY
  mafvec = mafvec(chr==19);
elseif AD_EXCLUDE_CHR_19
  mafvec = mafvec(chr~=19);
end

mafvec = colvec(mafvec);  % Need NHX below to be of type double so that glmfit will work right. If mafvec is single, NHX will be single and it won't work. %'
fprintf(1,'\n');

nsnps_from_full_LD_build = length(mafvec);
Hvec_from_full_LD_build = 2*mafvec.*(1-mafvec);
Hbar_from_full_LD_build = mean(Hvec_from_full_LD_build);

HAVE_NVEC = false;

datadir     = '/space/syn03/1/data/oleksandr/SynGen2/11015833/SUMSTAT';
datadirCFAN = '/space/syn03/1/data/cfan/SumStats';
datadirMTLO = '/space/md8/9/data/MMILDB/mtlo';
phenoName = ['_' pheno];
if DO_SCZ
  if DO_META
    fullFileName = [datadir '/PGC2_SCZ52_multisites.mat'];     fileNameInfixPheno = 'SCZ';
    fprintf(1,'Reading %s...',fullFileName);
    load(fullFileName,'logpmat','logormat','N_A_vec','N_U_vec');
    keyboard;
  else
    fullFileName = [datadir '/PGC_SCZ_2014.mat'];     fileNameInfixPheno = 'SCZ';
    fprintf(1,'Reading %s...\n',fullFileName);
    load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
    fprintf(1,'Done.\n');
    defvec = isfinite(zvec);
    
    nsnp = length(zvec);
    nsamp = 1;
    N_A = median(NCASE(defvec));     % 35476;
    N_U = median(NCONTROL(defvec));  % 46839;
    Neff = floor(4./(1./N_A+1./N_U));
    Nvec =  4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
    HAVE_NVEC = true;
  end
elseif DO_SCZ_SEP2017
    fullFileName = [datadir '/PGC_SCZ_0917.mat'];     fileNameInfixPheno = 'SCZ17';
    fprintf(1,'Reading %s...\n',fullFileName);
    load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
    fprintf(1,'Done.\n');
    defvec = isfinite(zvec);
    
    nsnp = length(zvec);
    nsamp = 1;
    N_A = median(NCASE(defvec));      % 51900;
    N_U = median(NCONTROL(defvec));   % 71675;
    Neff = floor(4./(1./N_A+1./N_U));
    Nvec =  4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
    HAVE_NVEC = true;
    
    defvec_A = (NCASE    > N_A - N_A/100) & (NCASE    < N_A + N_A/100);
    defvec_U = (NCONTROL > N_U - N_U/100) & (NCONTROL < N_U + N_U/100);
    defvec = defvec_A & defvec_U;
    N_A = median(NCASE(defvec));      % 51900;
    N_U = median(NCONTROL(defvec));   % 71675;
    Neff = floor(4./(1./N_A+1./N_U)); % 156582;
    zvec(~defvec) = nan;
elseif DO_BIP
  if DO_META
    fullFileName = [datadir '/PGC2_BIP32_multisites_9m.mat'];  fileNameInfixPheno = 'BIP';
    fprintf(1,'Reading %s...',fullFileName);
    load(fullFileName,'logpmat','betamat','Nvec_A','Nvec_U');
  else
    fullFileName = [datadir '/PGC_BIP_2016_qc.mat'];   fileNameInfixPheno = 'BIP';
    fprintf(1,'Reading %s...\n',fullFileName);
    load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
    fprintf(1,'Done.\n');
    defvec = isfinite(zvec);
    
    nsnp = length(zvec);
    nsamp = 1;
    N_A = median(NCASE(defvec));      % 20352;
    N_U = median(NCONTROL(defvec));   % 31358;
    Neff = floor(4./(1./N_A+1./N_U)); % 49367;
    Nvec =  4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
    HAVE_NVEC = true;
  end
elseif DO_CAD
    fullFileName = [datadir '/CARDIOGRAM_CAD_2015.mat'];   fileNameInfixPheno = 'CAD';
    fprintf(1,'Reading %s...\n',fullFileName);
    load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
    fprintf(1,'Done.\n');
    defvec = isfinite(zvec);
    
    nsnp = length(zvec);
    nsamp = 1;
    N_A = median(NCASE(defvec));       %  60801;
    N_U = median(NCONTROL(defvec));    % 123504;
    Neff = floor(4./(1./N_A+1./N_U));  % 162972;
    Nvec =  4./(1./NCASE+1./NCONTROL); % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
    HAVE_NVEC = true;
elseif DO_PUTAMEN
  fullFileName = [datadir '/ENIGMA_PUT_2016_noPGC_noGC.mat'];     fileNameInfixPheno = 'PUTAMEN';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 11598
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
elseif (DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO | DO_PALLIDUM | DO_THALAMUS)
  keyboard;
  DO_META = true;  % SEE ABOVE!
  if     DO_ACCUMBENS,   infix1 = 'Accumbens26'; fileNameInfixPheno = 'ACCUMBENS';
  elseif DO_AMYGDALA,    infix1 = 'Amygdala26';  fileNameInfixPheno = 'AMYGDALA';
  elseif DO_CAUDATE,     infix1 = 'Caudate26';   fileNameInfixPheno = 'CAUDATE';
  elseif DO_HIPPO,       infix1 = 'Hippo26';     fileNameInfixPheno = 'HIPPO';
  elseif DO_PALLIDUM,    infix1 = 'Pallidum26';  fileNameInfixPheno = 'PALLIDUM';
  else   DO_THALAMUS,    infix1 = 'Thalamus26';  fileNameInfixPheno = 'THALAMUS';
  end
  fullFileName = [datadir '/ENIGMA2_' infix1 '_9m.mat'];
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName,'logpmat','betamat','Nvec');  % Nvec is the 1x26 vector of sample sizes over the 26 sub-studies.
  Neffvec = Nvec;  clear Nvec;
elseif DO_MDD
  fullFileName = [datadir '/PGC_MDD_2012_lift.mat'];   fileNameInfixPheno = 'MDD';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  N_A = median(NCASE(defvec));     % 9240;
  N_U = median(NCONTROL(defvec));  % 9519;
  Neff = 4./(1./N_A+1./N_U);
  Nvec =  4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
elseif DO_MDD2018
  fullFileName = [datadir '/PGC_MDD_2018.mat'];   fileNameInfixPheno = 'MDD2018';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  N_A = median(NCASE(defvec));     %  59851;
  N_U = median(NCONTROL(defvec));  % 113154;
  Neff = floor(4./(1./N_A+1./N_U));    % 156582;
  Nvec =  4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec_A = (NCASE    > N_A - N_A/100) & (NCASE    < N_A + N_A/100);
  defvec_U = (NCONTROL > N_U - N_U/100) & (NCONTROL < N_U + N_U/100);
  defvec = defvec_A & defvec_U;
  N_A = median(NCASE(defvec));     %  59851;
  N_U = median(NCONTROL(defvec));  % 113154;
  Neff = floor(4./(1./N_A+1./N_U));       % 156582;
  zvec(~defvec) = nan;
elseif DO_HEIGHT
  fullFileName = [datadir '/GIANT_HEIGHT_2014_lift.mat'];     fileNameInfixPheno = 'HEIGHT';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 251747
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > Neff - Neff/100) & (Nvec < Neff + Neff/100);
  
  load('/space/md10/8/data/holland/genetics/defvecHeight_2010_2014_2018_11m.mat')
  defvec = defvecHeight_2010_2014_2018_11m;
  
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 252985
elseif DO_HEIGHT2010
  fullFileName = [datadir '/GIANT_HEIGHT_2010_lift.mat'];     fileNameInfixPheno = 'HEIGHT2010';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 133735
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > Neff - Neff/100) & (Nvec < Neff + Neff/100);
  
  load('/space/md10/8/data/holland/genetics/defvecHeight_2010_2014_2018_11m.mat')
  defvec = defvecHeight_2010_2014_2018_11m;
  
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 133802
elseif DO_HEIGHT2018
  fullFileName = [datadir '/GIANT_HEIGHT_2018_UKB.mat'];     fileNameInfixPheno = 'HEIGHT2018';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);  % length(find(defvec)) == 1,956,948
  
  nsnp = length(zvec);      % 11,015,833
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 704,545
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > Neff - Neff/100) & (Nvec < Neff + Neff/100);   % length(find(defvec)) == 1,625,495
  
  load('/space/md10/8/data/holland/genetics/defvecHeight_2010_2014_2018_11m.mat')
  defvec = defvecHeight_2010_2014_2018_11m;  % length(find(defvec)) == 1,246,423
  
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 707,868
elseif DO_EXTRAVERSION
  fileNameInfixPheno = 'EXTRAVERSION';
  load /space/md8/9/data/MMILDB/mtlo/23GPC/23andme_GPC2_extraversion_9m.mat;
  defvecTmp = isfinite(logpvec_23_gpc2_extraversion) & isfinite(nvec_23_gpc2_extraversion) & isfinite(zvec_23_gpc2_extraversion);
  zvec = zvec_23_gpc2_extraversion;  clear zvec_23_gpc2_extraversion;
  logpvec = logpvec_23_gpc2_extraversion;  clear logpvec_23_gpc2_extraversion;
  Nvec = nvec_23_gpc2_extraversion;        clear nvec_23_gpc2_extraversion;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_NEUROTICISM
  fileNameInfixPheno = 'NEUROTICISM';
  load /space/md8/9/data/MMILDB/mtlo/23GPC/23andme_GPC2_neuroticism_9m.mat;
  defvecTmp = isfinite(logpvec_23_gpc2_neuroticism) & isfinite(nvec_23_gpc2_neuroticism) & isfinite(zvec_23_gpc2_neuroticism);
  zvec = zvec_23_gpc2_neuroticism;        clear zvec_23_gpc2_neuroticism;
  logpvec = logpvec_23_gpc2_neuroticism;  clear logpvec_23_gpc2_neuroticism;
  Nvec = nvec_23_gpc2_neuroticism;        clear nvec_23_gpc2_neuroticism;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_OPENNESS
  fileNameInfixPheno = 'OPENNESS';
  load /space/md8/9/data/MMILDB/mtlo/23GPC/23andme_GPC1_openness_9m.mat;
  defvecTmp = isfinite(logpvec_23_gpc1_openness) & isfinite(nvec_23_gpc1_openness) & isfinite(zvec_23_gpc1_openness);
  zvec = zvec_23_gpc1_openness;  clear zvec_23_gpc1_openness;
  logpvec = logpvec_23_gpc1_openness;  clear logpvec_23_gpc1_openness;
  Nvec = nvec_23_gpc1_openness;        clear nvec_23_gpc1_openness;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_SBP
  keyboard
  fileNameInfixPheno = 'SBP';
elseif DO_BMI
  fullFileName = [datadir '/GIANT_BMI_2015_EUR_lift.mat'];     fileNameInfixPheno = 'BMI';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 233554
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > Neff - Neff/100) & (Nvec < Neff + Neff/100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 233881
elseif DO_CRP
  fileNameInfixPheno = 'CRP';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/CRP.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  logpvec = logpvec_crp;   clear logpvec_crp;
  zvec = -norminv(10.^-logpvec/2).*sign(zvec_crp);  clear zvec_crp;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_AD
  if EXCLUDE_APOE
    fullFileName = [datadir '/IGAP_AD_2013_noAPOE.mat'];     fileNameInfixPheno = 'AD2013noAPOE';
  else
    fullFileName = [datadir '/IGAP_AD_2013.mat'];            fileNameInfixPheno = 'AD2013';
  end
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  
  if AD_INCLUDE_CHR_19_ONLY
    zvec = zvec(chr==19);
    NCASE = NCASE(chr==19);
    NCONTROL = NCONTROL(chr==19);
    logpvec = logpvec(chr==19);
  elseif AD_EXCLUDE_CHR_19
    zvec = zvec(chr~=19);
    NCASE = NCASE(chr~=19);
    NCONTROL = NCONTROL(chr~=19);
    logpvec = logpvec(chr~=19);
  end
  
  defvec = isfinite(zvec);                % 7642185
  length(find(defvec))
  zvec(~defvec) = nan;             % Some might be Inf: change to nan
  logpvec(~defvec) = nan;
  
  nsnp = length(zvec);
  nsamp = 1;
  N_A = median(NCASE(defvec));     % 17008;
  N_U = median(NCONTROL(defvec));  % 37154;
  Neff = 4./(1./N_A+1./N_U);       % 46668;
  Nvec = 4./(1./NCASE+1./NCONTROL);  
  HAVE_NVEC = true;
elseif DO_AD2018
  if EXCLUDE_APOE
    % First, get the 2013 data with no APOE...
    fullFileName = [datadir '/IGAP_AD_2013_noAPOE.mat'];     fileNameInfixPheno = 'AD';
    fprintf(1,'Reading %s...\n',fullFileName);
    load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
    fprintf(1,'Done.\n');
    defvec2013_NO_APOE = isfinite(zvec);                               % length(find(defvec2013_NO_APOE)) == 5742974
    clear zvec;
    
    % Next, get the 2013 data with APOE...
    fullFileName = [datadir '/IGAP_AD_2013.mat'];       
    load(fullFileName);
    defvec2013_WITH_APOE = isfinite(zvec);                             % length(find(defvec2013_WITH_APOE)) == 5745087
    defvec2013_APOE_ONLY = defvec2013_WITH_APOE & ~defvec2013_NO_APOE; % length(find(defvec2013_APOE_ONLY)) == 2113   ALL of these are in 2018 data
    clear zvec;
  end
  
  % Now get the real thing...
  fullFileName = [datadir '/PGC_AD_2018_biorxiv_feb.mat'];     fileNameInfixPheno = 'AD2018';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec2018_WITH_APOE = isfinite(zvec);  % 7644298
  
  % length(find(abs(zvec)>5.45 &  defvec2013_APOE_ONLY))           == 587
  % length(find(abs(zvec)>5.45 & ~defvec2013_APOE_ONLY & chr==19)) == 117
  
  if EXCLUDE_APOE
    zvec(defvec2013_APOE_ONLY) = nan;
  end
  if AD_EXCLUDE_CHRs_6_11_19
    ivecExclude = chr==6;
    ivecExclude(chr==11) = true;
    ivecExclude(chr==19) = true;
    zvec(ivecExclude) = nan;
  end
  if AD_INCLUDE_CHR_19_ONLY
   %ivecExclude = chr~=19;    length(find(chr==19)) == 261744
   %zvec(ivecExclude) = nan;
    zvec = zvec(chr==19);
    NCASE = NCASE(chr==19);
    NCONTROL = NCONTROL(chr==19);
    logpvec = logpvec(chr==19);
  elseif AD_EXCLUDE_CHR_19
    zvec = zvec(chr~=19);
    NCASE = NCASE(chr~=19);
    NCONTROL = NCONTROL(chr~=19);
    logpvec = logpvec(chr~=19);
  end
  
  defvec = isfinite(zvec);                % 7642185
  length(find(defvec))
  zvec(~defvec) = nan;             % Some might be Inf: change to nan
  logpvec(~defvec) = nan;
  
  nsnp = length(zvec);
  nsamp = 1;
  N_A = median(NCASE(defvec));     %  71880;
  N_U = median(NCONTROL(defvec));  % 383378;
  Neff = 4./(1./N_A+1./N_U);       % 242124;
  Nvec = 4./(1./NCASE+1./NCONTROL);  
  HAVE_NVEC = true;
elseif DO_HDL
  fileNameInfixPheno = 'HDL';
  fullFileName = [datadir '/LIPIDS_HDL_2013.mat'];
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 94295
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  figure(999); clf; hist(Nvec(defvec), 100);
  defvec = (Nvec > 91000) & (Nvec < 95000); % 1962471
  figure(998); clf; hist(Nvec(defvec), 100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 94311
elseif DO_LDL
  fileNameInfixPheno = 'LDL';
  fullFileName = [datadir '/LIPIDS_LDL_2013.mat'];
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);  % 2013836
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 89873
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  figure(999); clf; hist(Nvec(defvec), 100);
  defvec = (Nvec > 88000) & (Nvec < 90000);  % 1693105
  figure(998); clf; hist(Nvec(defvec), 100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 89888
elseif DO_TC
  fileNameInfixPheno = 'TG';
  fullFileName = [datadir '/LIPIDS_TG_2013.mat'];
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 90997
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > 87000) & (Nvec < 92000);
  figure(998); clf; hist(Nvec(defvec), 100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 89888
elseif DO_TG
  fileNameInfixPheno = 'TG';
  fullFileName = [datadir '/LIPIDS_TG_2013.mat'];
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 90997
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > 87000) & (Nvec < 92000);
  figure(998); clf; hist(Nvec(defvec), 100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 91013
elseif DO_ReactionTime
  fileNameInfixPheno = 'ReactionTime';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/ReactionTime.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  zvec = zvec_reactiontime;         clear zvec_reactiontime;
  logpvec = -log10(normcdf(-abs(zvec))*2);    clear logpvec_reactiontime;
  nsnps9m = length(zvec);  % 
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_COG
  fileNameInfixPheno = 'COG';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/COG.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  zvec = zvec_cog;                                  clear zvec_cog;
  logpvec = -log10(normcdf(-abs(zvec))*2);          clear logpvec_cog;
  nsnps9m = length(zvec);  % 
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_COG2018
  fileNameInfixPheno = 'COG2018';
  fullFileName = [datadir '/CTG_COG_2018.mat'];
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 262529
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > Neff - Neff/100) & (Nvec < Neff + Neff/100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 89888
elseif DO_ICV_Enigma2
  fileNameInfixPheno = 'ICV_Enigma2';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/ICV_Enigma2.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  logpvec = logpvec_icv_enigma2;                           clear logpvec_icv_enigma2;
  zvec = -norminv(10.^-logpvec/2).*sign(zvec_icv_enigma2); clear zvec_icv_enigma2;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_VNR
  fileNameInfixPheno = 'VNR';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/VNR.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  zvec = zvec_vnr;         clear zvec_vnr;
  logpvec = -log10(normcdf(-abs(zvec))*2);    clear logpvec_vnr;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
elseif DO_EduYear
  fullFileName = [datadir '/SSGAC_EDU_2016.mat'];     fileNameInfixPheno = 'EduYear';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 293723
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
elseif DO_CA
  fileNameInfixPheno = 'CogentAll';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/COGENT_All_9m.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  zvec = zvec_cogent;         clear zvec_cogent;
  logpvec = -log10(normcdf(-abs(zvec))*2);    clear logpvec_cogent;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
  Nvec = nvec_cogent;        clear nvec_cogent;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
elseif DO_CO
  fileNameInfixPheno = 'CogentOnly';
  fullFileName = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Data/COGENT_only_9m.mat';
  fprintf(1,'Reading %s...',fullFileName);
  load(fullFileName);
  zvec = zvec_cogent;         clear zvec_cogent;
  logpvec = -log10(normcdf(-abs(zvec))*2);    clear logpvec_cogent;
  nsnps9m = length(zvec);  % 9279485
  nsnp = nsnps9m;
  nsamp = 1;
  Nvec = nvec_cogent;        clear nvec_cogent;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
elseif DO_IQ
  fullFileName = [datadir '/CTG_INTELLIGENCE_2017.mat'];     fileNameInfixPheno = 'IQ';
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  
  nsnp = length(zvec);
  nsamp = 1;
  Neff = median(N(isfinite(N)));  % 54119
  Nvec = N;   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
  
  defvec = (Nvec > Neff - Neff/100) & (Nvec < Neff + Neff/100);
  zvec(~defvec) = nan;
  Neff = median(N(defvec));  % 54119
elseif DO_CD
    fullFileName = [datadir '/IIBDGC_CD_2017_lift.mat'];     fileNameInfixPheno = 'CD';
    fprintf(1,'Reading %s...\n',fullFileName);
    load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
    fprintf(1,'Done.\n');
    defvec = isfinite(zvec);
    
    nsnp = length(zvec);
    nsamp = 1;
    N_A = median(NCASE(defvec));     % 12194;
    N_U = median(NCONTROL(defvec));  % 34915;
    Neff = 4./(1./N_A+1./N_U);       % 36151; CHANGED THE 2 to 4.
    Nvec = 4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
    HAVE_NVEC = true;
elseif DO_UC
  fileNameInfixPheno = 'UC';
  fullFileName = [datadir '/IIBDGC_UC_2017_lift.mat'];
  fprintf(1,'Reading %s...\n',fullFileName);
  load(fullFileName); % INFO NCASE NCONTROL OR PVAL SE logpvec nvec zvec: 11015833x1 
  fprintf(1,'Done.\n');
  defvec = isfinite(zvec);
  nsnp = length(zvec);
  nsamp = 1;
  N_A = median(NCASE(defvec));     % 12366;
  N_U = median(NCONTROL(defvec));  % 34915;
  Neff = 4./(1./N_A+1./N_U);       % 36527; CHANGED THE 2 to 4.
  Nvec = 4./(1./NCASE+1./NCONTROL);   % Sample size for each SNP.  (NB: This is NOT a vector of sub-study sample sizes.)
  HAVE_NVEC = true;
else
  keyboard;
end
fprintf(1,'done\n');
if DO_META & (DO_SCZ | DO_SCZ_SEP2017 | DO_BIP | DO_PUTAMEN | DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO | DO_PALLIDUM | DO_THALAMUS)
  nsnps9m = size(logpmat,1);    % 9279485
end

if DO_SCZ & DO_META
  Neffvec = 4./(1./N_A_vec+1./N_U_vec);                           % Neffvec is the 1x52 vector of sample sizes over the 52 sub-studies.
elseif DO_BIP & DO_META
  Neffvec = 4./(1./Nvec_A+1./Nvec_U);                             % Neffvec is the 1x32 vector of sample sizes over the 32 sub-studies. % sum(Neffvec) = Neff = 46,582
elseif DO_META & (DO_PUTAMEN | DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO | DO_PALLIDUM | DO_THALAMUS)
 %Neffvec is the 1x26 vector of sample sizes over the 26 sub-studies.
  Neff    = sum(Neffvec);   % Sum over substudies
elseif DO_CRP
  Neff = 82725;
elseif DO_TC
  Neff = 188577;
elseif DO_TG
  Neff = 188577;
elseif DO_ReactionTime
  Neff = 111483;
elseif DO_COG
  Neff = 53949;
elseif DO_ICV_Enigma2
  Neff = 13357;
elseif DO_VNR
  Neff = 36035;
end

if DO_SCZ & DO_META
  zmat = -norminv(10.^-logpmat/2).*sign(logormat);
elseif DO_META & (DO_BIP | DO_PUTAMEN | DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO | DO_PALLIDUM | DO_THALAMUS)
  zmat = -norminv(10.^-logpmat/2).*sign(betamat);
end
if DO_META & (DO_SCZ | DO_BIP | DO_PUTAMEN | DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO | DO_PALLIDUM | DO_THALAMUS)
  [zvec logpvec Neff] = GenStats_meta(zmat,Neffvec);   % Neff = sum(Neffvec);  where Neffvec is the vector of substudy sample sizes.
  nsnp = size(zmat,1); nsamp = size(zmat,2); studyindlist_disc = [1:nsamp];  % nsamp=52
end

nsnpOrig = nsnp;

Hvec = 2*mafvec.*(1-mafvec);
Lvec = tldvec;

ldr2binsNum     = size(LDr2hist,2);  %  100
ldr2binsEdges   = linspace( 0,1,ldr2binsNum+1);
ldr2binsCenters = nan(1,ldr2binsNum); for i=1:ldr2binsNum, ldr2binsCenters(i) = (ldr2binsEdges(i+1)+ldr2binsEdges(i))/2; end

nsnps = size(LDr2hist,1);

if ~exist('minr2','var'),  keyboard;  end

tmp = find(ldr2binsEdges <= minr2,1,'last');
if isempty(tmp),  tmp=1;  end
minr2bin = tmp;

maxr2 = 1.0;
tmp = find(ldr2binsEdges >= maxr2,1); if isempty(tmp),          keyboard;  end
maxr2bin = tmp-1;                     if maxr2bin <= minr2bin,  keyboard;  end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tldvec_alt = zeros(nsnps,1);
for i=1:nsnps
  tldvec_alt(i) = sum(LDr2hist(i,minr2bin:end).*ldr2binsCenters(minr2bin:end),2);
end
% Use tldvec_alt instead of the above tldvec?  tldvec is only used as a filter in defvec and for the H-L binning.
tldvec = tldvec_alt;

Lvec = tldvec;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

numSNPsInLDr2_gt_r2min_vec = sum(LDr2hist(:,minr2bin:end),2);

ldr2TruncBinsNum = ldr2binsNum - minr2bin + 1;

nr2binsOrig = maxr2bin-minr2bin+1;

numOrigPerNew = nr2binsOrig/nr2binsNew;

LDr2histReduced = zeros(nsnps,nr2binsNew);
HhistReduced    = nan(nsnps,nr2binsNew);

Hhist(isnan(Hhist)) = 0;

jOrigMaxPrev = 0;
for j=1:nr2binsNew
  jOrigMin = minr2bin+(j-1)*floor(numOrigPerNew);
  jOrigMax = jOrigMin + floor(numOrigPerNew) - 1;
  if(j>1 & jOrigMin ~= jOrigMaxPrev+1),  keyboard;  end
  if j==nr2binsNew,  jOrigMax = maxr2bin;  end          % Shove all the remainder into the last bin.
  fprintf(1,'jOrigMin %2d  jOrigMax %2d\n',jOrigMin,jOrigMax);
  jOrigMaxPrev = jOrigMax;
  LDr2histReduced(:,j) = sum(LDr2hist(:,jOrigMin:jOrigMax),2);
  HhistReduced(:,j)    = sum(   Hhist(:,jOrigMin:jOrigMax).*LDr2hist(:,jOrigMin:jOrigMax),2)./LDr2histReduced(:,j);
  if PRUNE & USE_R2MAT
    for i=1:nsnps
     %r2mat(i,j) = sum(LDr2hist(i,jOrigMin:jOrigMax).*bgn_ldr2binsCenters)/sum(tmpMat(i,:));
      r2mat(i,j) = sum(LDr2hist(i,jOrigMin:jOrigMax).*ldr2binsCenters(jOrigMin:jOrigMax))/sum(LDr2hist(i,jOrigMin:jOrigMax));
    end
  end
end

ldr2binsNum = size(LDr2histReduced,2);

ldr2binsEdges   = linspace(minr2,maxr2,ldr2binsNum+1);
ldr2binsCenters = nan(1,ldr2binsNum); for i=1:ldr2binsNum, ldr2binsCenters(i) = (ldr2binsEdges(i+1)+ldr2binsEdges(i))/2; end

numSNPsInLDr2_gt_r2min_vec_Reduced = sum(LDr2histReduced(:,1:end),2);
if length(find(numSNPsInLDr2_gt_r2min_vec_Reduced==0)),  keyboard;  end

r2edges   = ldr2binsEdges;
nrbins    = length(r2edges)-1;   % r2edges such that r2edges(j+1)-r2edges(j) bin-widths are equal for all j.
r2meanvec = ldr2binsCenters;     % Mean r^2 for each LD window. Eqn 53 in Methods.
r2fracmat = LDr2histReduced./repmat(numSNPsInLDr2_gt_r2min_vec, [1 ldr2binsNum]);
if length(find(~isfinite(r2fracmat(:)))),  keyboard;  end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ESTIMATE_TLD_MAX_AND_LD_BLOCK_SIZE_MAX
%figure(998); clf; hist(numSNPsInLDr2_gt_r2min_vec_Reduced,100)
[nc nv]= hist(numSNPsInLDr2_gt_r2min_vec_Reduced,100);
binMax = find(nc==max(nc),1);
binNum = find(nc<max(nc)/100 & nv>nv(binMax),1);
LD_BLOCK_SIZE_MAX = round(nv(binNum))  % The higher pi1 the lower this might need to be.

%figure(997); clf; hist(tldvec,100)
[nc nv]= hist(tldvec,100);
binMax = find(nc==max(nc),1);
binNum = find(nc<max(nc)/100 & nv>nv(binMax),1);
TLD_MAX = round(nv(binNum))

defvecTmp = numSNPsInLDr2_gt_r2min_vec_Reduced < LD_BLOCK_SIZE_MAX & tldvec < TLD_MAX;
%figure(998); clf; hist(numSNPsInLDr2_gt_r2min_vec_Reduced(defvecTmp),100)
%figure(997); clf; hist(tldvec(defvecTmp),100)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tldInfix = '';
nldInfix = '';

defvec = isfinite(Hvec + tldvec + zvec);
defvec = defvec & mafvec >=0.01;
defvec = defvec & tldvec <= TLD_MAX; tldInfix = ['_TLD_MAX_' num2str(TLD_MAX)];
defvec = defvec & numSNPsInLDr2_gt_r2min_vec <= LD_BLOCK_SIZE_MAX; nldInfix  = ['_NLD_MAX_' num2str(LD_BLOCK_SIZE_MAX)];

figInfix = [tldInfix nldInfix];

if HAVE_NVEC  % Sample size vec for each SNP
  defvec = defvec & isfinite(Nvec);
  Neff = floor(median(Nvec(defvec)))  % More robust to outliers. 112647 for SCZ_SEP2017
  
  figure(999); clf; hist(Nvec(defvec), 100);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate nominal genomic inflation from data: lamGC_median_QQobsNet
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hv_z = linspace(0,38,50000);
hv_logp = -log10(2*normcdf(-abs(hv_z)));

ci_alpha = 0.05;

% f is the number of SNPs that are represented, on average, by each SNP.
% n is he total number of SNPs, so n/f is the expected number of independent SNPs.
f=10;

[logqvec hv_logp  logqmat_ci] = GenStats_QQ_plot_withCI(logpvec(defvec),hv_z,ci_alpha,f);
% Note: hv_logp returned here is exactly the same as the one defined above.
ix=find(logqvec==max(logqvec(isfinite(logqvec))),1);
fig_xmax = ceil(logqvec(ix));
fig_ymax = ceil(hv_logp(ix));

ci1 = logqmat_ci(:,1);
ci2 = logqmat_ci(:,2);

figure(444); clf;
GenStats_QQ_plot_withCI(logpvec(defvec),hv_z,ci_alpha,f,phenoName(2:end));
drawnow;
figure(444); ylim([0 fig_ymax]); xlim([0 fig_xmax]); hold off;
drawnow;

NORMALIZE_CDFVEC = false;

qMedian = 0.5;
z2_medianNull = chi2inv(qMedian,1);     % 0.454

lamGC_medianFromQQ_data = lamGCfromQQ(logqvec,hv_logp)                 
lamGC_median_data       = median(zvec(defvec).^2)        /z2_medianNull
% Same as                 median(zvec(isfinite(zvec)).^2)/z2_medianNull
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X = tldvec;
NHX = Neff*repmat(Hvec,[1 size(X,2)]).*X;

if PRUNE
  filename = '/space/md10/8/data/holland/genetics/LD_1kGPhase3_hg19_11m/LD_r2_gt_p8_chrs_1_22_from_1kGPhase3_hg19_1kGHG1pc_11m.mat';
  load(filename); % LDr2_p8sparse  11015833x11015833   4127399167  logical    sparse
  
  LDmat = LDr2_p8sparse;   clear LDr2_p8sparse;
  
  if AD_INCLUDE_CHR_19_ONLY
    LDmat = LDmat(chr==19,chr==19);
  elseif AD_EXCLUDE_CHR_19
    LDmat = LDmat(chr~=19,chr~=19);
  end
end

if(~PRUNE),  nrep=1;  end
opts_struct = struct('nprune', nrep);

ivecFinite = find(defvec);
nsnpsFiniteTotal = length(ivecFinite);

HvecFinite = Hvec(ivecFinite);         % H = 2*maf*(1-maf),  0 <= H <= 0.5
LvecFinite = Lvec(ivecFinite);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if EQUAL_SIZE_HLB_BINS | FIXED_PERCENTILE_HLB_BINS
  if EQUAL_SIZE_HLB_BINS
    HbinsEdges   = linspace(min(HvecFinite),max(HvecFinite),nHbins+1);
    HbinsCenters = nan(1,nHbins); for i=1:nHbins, HbinsCenters(i) = (HbinsEdges(i+1)+HbinsEdges(i))/2; end
    
    LbinsEdges   = linspace(min(LvecFinite),max(LvecFinite),nLbins+1);
    LbinsCenters = nan(1,nLbins); for i=1:nLbins, LbinsCenters(i) = (LbinsEdges(i+1)+LbinsEdges(i))/2; end
    
    BbinsEdges   = linspace(1,LD_BLOCK_SIZE_MAX,nBbins+1);  % Same for all
    BbinsCenters = nan(1,nBbins); for i=1:nBbins, BbinsCenters(i) = (BbinsEdges(i+1)+BbinsEdges(i))/2; end
    
  else  % FIXED_PERCENTILE_HLB_BINS
    
    HbinsEdges = prctile(HvecFinite,linspace(1,100,nHbins+1));
    HbinsCenters = nan(1,nHbins); for i=1:nHbins, HbinsCenters(i) = (HbinsEdges(i+1)+HbinsEdges(i))/2; end
    
    MAKE2PARTSof1stLDBIN = false;
    if MAKE2PARTSof1stLDBIN  % nLDbins=5
      LbinsEdgesPercentiles = prctile(LvecFinite,linspace(1,100,(nLbins-1)+1));
      LbinsEdges   = [LbinsEdgesPercentiles(1) LbinsEdgesPercentiles(2)/4 LbinsEdgesPercentiles(2:end)];
    else
      LbinsEdges = prctile(LvecFinite,linspace(1,100,nLbins+1));
    end
    LbinsCenters = nan(1,nLbins); for i=1:nLbins, LbinsCenters(i) = (LbinsEdges(i+1)+LbinsEdges(i))/2; end
    
    BbinsEdges = prctile(BvecFinite,linspace(1,100,nBbins+1));
    BbinsCenters = nan(1,nBbins); for i=1:nBbins, BbinsCenters(i) = (BbinsEdges(i+1)+BbinsEdges(i))/2; end
  end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delextreme = 38.0;
numDel = 2^10;  % 2^9
delvals = linspace(-delextreme,delextreme,numDel+1); delstep = delvals(2)-delvals(1); 
tickvals = 5*[-10:10]; ticks = interp1(delvals,1:length(delvals),tickvals); tickvals = tickvals(isfinite(ticks)); ticks = ticks(isfinite(ticks));
if mod(length(delvals),2)~=0, delvals = delvals(1:end-1); end % Make sure there''s an even number of zbins (for fft/fftshift)

upsampfact = 1;
%upsampfact = 16; % This is needed to handle tiny sig_b * r^2 -- should find more computationally efficient solution
zvals = linspace(delvals(1),-delvals(1),upsampfact*length(delvals)+1); zvals = zvals(1:end-1);
zstep_orig = delvals(2)-delvals(1);
zstep = zvals(2)-zvals(1); Fs = 1/zstep; fvec = -1/2*Fs*zvals/zvals(1);

dz = zstep;
zextreme = delextreme;
nzbins = length(zvals);
zvals_disc = zvals;
nzvals = length(zvals_disc);                      % nzbins

if 1
  sumstats = cell(1,nrep);
  pruneidxmat = false(size(defvec,1), opts_struct.nprune);
  if ~PRUNE
    ivecrepiLogical = defvec;
  end
  time0 = now;
  RepsTime0 = now;
  for repi = 1:nrep
    if(RANDOM_PRUNE)
      tmp=rand(size(defvec,1),1);
      tmp(~defvec) = NaN;  % Should only include SNPs that have defined z-scores and maf and tld
      ldthresh = 0.8;  % For SNPs with LD greater than ldthresh, randomly choose one to keep and remove the rest.
      ivecrepiLogical  = isfinite(FastPrune(tmp, LDmat));           % LDmat logical, set using: r^2>0.8 ==> "true", else "false".
    elseif(NONRANDOM_PRUNE)
      logpvecTmp = logpvec;
      logpvecTmp(~defvec) = NaN;  % Should only include SNPs that have defined z-scores and maf and tld. Some finite logpvec els have nan z b.c. sign missing.
      ivecrepiLogical  = isfinite(FastPrune(logpvecTmp, LDmat));    % LDmat logical, set using: r^2>0.8 ==> "true", else "false".
      clear logpvecTmp;
    end
    ivecR = find(ivecrepiLogical);
    pruneidxmat(:,repi) = ivecrepiLogical;                          % LDmat logical, set using: r^2>0.8 ==> "true", else "false".
    
    if(PRUNE)
      zdvecR = zvec(ivecR);
      HvecR  = Hvec(ivecR);
      LvecR  = Lvec(ivecR);
      if HAVE_NVEC
        NvecR = Nvec(ivecR);
      end
      nLvecR = numSNPsInLDr2_gt_r2min_vec(ivecR);  % NOTE: numSNPsInLDr2_gt_r2min_vec itself does not incorporate any pruning.
      r2fracmatR = r2fracmat(ivecR,:);             % NOTE: r2fracmat                  itself does not incorporate any pruning.
      HhistmatR  = HhistReduced(ivecR,:);
      nsnpsFinite = length(find(ivecR));           % See: buildLDhistAndTLD.m;
    else
      zdvecR = zvec(defvec);
      HvecR  = Hvec(defvec);
      LvecR  = Lvec(defvec);
      if HAVE_NVEC
        NvecR = Nvec(defvec);
      end
      nLvecR = numSNPsInLDr2_gt_r2min_vec(defvec);
      r2fracmatR = r2fracmat(defvec,:);
      HhistmatR  = HhistReduced(defvec,:);
      nsnpsFinite = length(find(defvec));
    end
    
    cntmat     = NaN(nzvals,nHbins,nLbins,nBbins);
    nsnpsHLmat = NaN(nHbins,nLbins);
    nsnpsHLBmat= NaN(nHbins,nLbins,nBbins);
    nLDmat     = NaN(nHbins,nLbins,nBbins);           % No need to store all the nzvals histmean data: compress to s single value
    Hmat       = NaN(nHbins,nLbins,nBbins);           % No need to store all the nzvals histmean data: compress to s single value
    Lmat       = NaN(nHbins,nLbins,nBbins);           % No need to store all the nzvals histmean data: compress to s single value
    LbinsEdgesMat   = NaN(nHbins,nLbins+1);
    LbinsCentersMat = NaN(nHbins,nLbins);
    BbinsEdgesMat   = NaN(nHbins,nLbins,nBbins+1);
    BbinsCentersMat = NaN(nHbins,nLbins,nBbins);
    Nmat = [];
    if HAVE_NVEC
      Nmat     = NaN(nHbins,nLbins,nBbins);           % No need to store all the nzvals histmean data: compress to s single value
    end
    r2fracmat2 = NaN(nrbins, nHbins, nLbins,nBbins);  % No need to store all the nzvals histmean data: compress to s single value
    Hhistmat2  = NaN(nrbins, nHbins, nLbins,nBbins);  % No need to store all the nzvals histmean data: compress to s single value
    
    if VARIABLE_PERCENTILE_HLB_BINS  % Variable: depending on the mix of SNPs involved
      HbinsEdges = prctile(HvecR,linspace(1,100,nHbins+1));
      HbinsEdges(1)   = min(HvecR); % 0
      HbinsEdges(end) = max(HvecR); % 0.5;
      HbinsCenters = nan(1,nHbins); for i=1:nHbins, HbinsCenters(i) = (HbinsEdges(i+1)+HbinsEdges(i))/2; end
    end
    
    HbinsTime0 = now;
    for Hbini = 1:nHbins
      if Hbini==nHbins
        ivecH = (HvecR >= HbinsEdges(Hbini)) & (HvecR <= HbinsEdges(Hbini+1));
      else
        ivecH = (HvecR >= HbinsEdges(Hbini)) & (HvecR <  HbinsEdges(Hbini+1));
      end
      LbinsTime0 = now;
      if VARIABLE_PERCENTILE_HLB_BINS
        LbinsEdges = prctile(LvecR(ivecH),linspace(1,100,nLbins+1));
        LbinsEdges(1)   = min(LvecR(ivecH));  % Otherwise might be greater by 1;
        LbinsEdges(end) = max(LvecR(ivecH));  % To be sure; inf;
        LbinsCenters = nan(1,nLbins); for i=1:nLbins, LbinsCenters(i) = (LbinsEdges(i+1)+LbinsEdges(i))/2; end
      end
      LbinsEdgesMat(Hbini,:) = LbinsEdges;
      LbinsCentersMat(Hbini,:) = LbinsCenters;
      LvecRH = LvecR(ivecH);
      for Lbini = 1:nLbins
        if Lbini==nLbins
          ivecL = (LvecRH >= LbinsEdges(Lbini)) & (LvecRH <= LbinsEdges(Lbini+1));
        else
          ivecL = (LvecRH >= LbinsEdges(Lbini)) & (LvecRH <  LbinsEdges(Lbini+1));
        end
        ivecHf = find(ivecH);
        ivecHLf= ivecHf(ivecL);  % actual indices for HvecR, LvecR, zdvecR;
        
        nsnpsHL = length(ivecHLf);
        nsnpsHLmat(Hbini,Lbini) = nsnpsHL;
        if ~nsnpsHL,  continue;  end
        
        fracSnpsHL = nsnpsHL/nsnpsFinite;
        
        zdvecHLR = zdvecR(ivecHLf);
        HvecHLR  = HvecR(ivecHLf);
        LvecHLR  = LvecR(ivecHLf);
        if HAVE_NVEC
          NvecHLR = NvecR(ivecHLf);
        end
        nLvecHLR = nLvecR(ivecHLf);
        r2fracmatHLR = r2fracmatR(ivecHLf,:);
        HhistmatHLR  = HhistmatR(ivecHLf,:);
        
        blockSizesShortVec = nLvecHLR;
        minBlockSize  = min(blockSizesShortVec);
        maxBlockSize  = max(blockSizesShortVec);
        
        if VARIABLE_PERCENTILE_HLB_BINS
          BbinsEdges = prctile(blockSizesShortVec,linspace(1,100,nBbins+1));
          BbinsEdges(1)   = minBlockSize;  % Otherwise might be greater by 1;
          BbinsEdges(end) = maxBlockSize;  % To be sure;
          BbinsCenters = nan(1,nBbins); for i=1:nBbins, BbinsCenters(i) = (BbinsEdges(i+1)+BbinsEdges(i))/2; end
        end
        BbinsEdgesMat  (Hbini,Lbini,:) = BbinsEdges;
        BbinsCentersMat(Hbini,Lbini,:) = BbinsCenters;
        
        for Bbini = 1:nBbins
          if Bbini==nBbins
            ivecHLB  = (blockSizesShortVec >= BbinsEdges(Bbini)) & (blockSizesShortVec <= BbinsEdges(Bbini+1));  % Could have a SNP with blocksize equal to BbinsEdges(nBbins+1).
          else
            ivecHLB  = (blockSizesShortVec >= BbinsEdges(Bbini)) & (blockSizesShortVec < BbinsEdges(Bbini+1));
          end
          ivecHLBf = find(ivecHLB);
          nsnpsHLB = length(ivecHLBf);
          nsnpsHLBmat(Hbini,Lbini,Bbini) = nsnpsHLB;
          
          if ~nsnpsHLB,  continue;  end
          fracSnpsHLB = nsnpsHLB/nsnpsHL;   % ==> Prob(HL)=1 ALL SNPs   
          
          zdvecHLBR = zdvecHLR(ivecHLBf);
          HvecHLBR  = HvecHLR(ivecHLBf);
          LvecHLBR  = LvecHLR(ivecHLBf);
          if HAVE_NVEC
            NvecHLBR = NvecHLR(ivecHLBf);
          end
          nLvecHLBR = nLvecHLR(ivecHLBf);
          r2fracmatHLBR = r2fracmatHLR(ivecHLBf,:);
          HhistmatHLBR  = HhistmatHLR(ivecHLBf,:);
          
          [Hvals      Hvals_cnt]      = histmean_dh([-zdvecHLBR; zdvecHLBR], [HvecHLBR;   HvecHLBR],   zvals_disc);  Hvals      = colvec(Hvals);      Hvals_cnt = colvec(Hvals_cnt);
          [nLDvals    nLDvals_cnt]    = histmean_dh([-zdvecHLBR; zdvecHLBR], [nLvecHLBR;  nLvecHLBR],  zvals_disc);  nLDvals    = colvec(nLDvals);    nLDvals = round(nLDvals);
          [Lvals      Lvals_cnt]      = histmean_dh([-zdvecHLBR; zdvecHLBR], [LvecHLBR;   LvecHLBR],   zvals_disc);  Lvals      = colvec(Lvals);      Lvals_cnt = colvec(Lvals_cnt);
          if HAVE_NVEC
            [Nvals    Nvals_cnt]      = histmean_dh([-zdvecHLBR; zdvecHLBR], [NvecHLBR;   NvecHLBR],   zvals_disc);  Nvals      = colvec(Nvals);      Nvals_cnt = colvec(Nvals_cnt);
          end
          r2fracmatVals = nan(nzvals,nrbins);
          HhistmatVals  = nan(nzvals,nrbins);
          for rbini = 1:nrbins
            r2tmp = r2fracmatHLBR(:,rbini);
            [r2fracVals r2fracmatVals_cnt] = histmean_dh([-zdvecHLBR; zdvecHLBR], [r2tmp;  r2tmp], zvals_disc);  r2fracVals = colvec(r2fracVals);
            r2fracmatVals(:,rbini) = r2fracVals;
            
            Htmp = HhistmatHLBR(:,rbini);
            [HhistVals HhistmatVals_cnt] = histmean_dh([-zdvecHLBR; zdvecHLBR], [Htmp;  Htmp], zvals_disc);  HhistVals = colvec(HhistVals);
            HhistmatVals(:,rbini) = HhistVals;
          end
          
         nLDval = mean(nLDvals(find(isfinite(nLDvals))));
         Hval   = mean(Hvals(find(isfinite(Hvals))));
         Lval   = mean(Lvals(find(isfinite(Lvals))));
         
          if HAVE_NVEC
            Nval = floor(mean(Nvals(find(isfinite(Nvals)))));
          end
          r2fracmatVal = zeros(nrbins,1);
          for rbini = 1:nrbins
            tmp=r2fracmatVals(:,rbini);
            if length(find(isfinite(tmp)))
             r2fracmatVal(rbini) = mean(tmp(isfinite(tmp)));
            end
          end
          HhistmatVal = zeros(nrbins,1);
          for rbini = 1:nrbins
            tmp=HhistmatVals(:,rbini);
            meantmp = mean(tmp(isfinite(tmp)));
            HhistmatVal(rbini) = meantmp;
          end
          
          % NOTE: sum(Hvals_cnt) is TWICE nsnpsHLB
          
          cntmat(:,Hbini,Lbini,Bbini) = Hvals_cnt;           % NEED to store all the histmean count data
          nLDmat(Hbini,Lbini,Bbini)   = nLDval;
          Hmat(Hbini,Lbini,Bbini)     = Hval;
          Lmat(Hbini,Lbini,Bbini)     = Lval;
          if HAVE_NVEC
            Nmat(Hbini,Lbini,Bbini)   = Nval;  % A clonky way of handling this parameter.
          end
          r2fracmat2(:,Hbini,Lbini,Bbini) = r2fracmatVal;
          Hhistmat2(:,Hbini,Lbini,Bbini) = HhistmatVal;
        end  % for Bbini = 1:nBbins
      end    % for Lbini = 1:nLbins
    end      % for Hbini = 1:nHbins
    if sum(nsnpsHLmat(:)) ~= nsnpsFinite,  keyboard;  end
    sumstats{repi} = struct('ivecrepiLogical', ivecrepiLogical, 'zvals_disc', zvals_disc,...
                            'Neff', Neff,...
                            'nsnpsFinite', nsnpsFinite, 'nsnpsHLmat', nsnpsHLmat, 'nsnpsHLBmat', nsnpsHLBmat,...
                            'cntmat', cntmat, 'nLDmat', nLDmat, 'Hmat', Hmat, 'Lmat', Lmat, 'Nmat', Nmat, 'r2fracmat2',r2fracmat2, 'Hhistmat2',Hhistmat2,...
                            'HbinsEdges',    HbinsEdges,    'HbinsCenters',    HbinsCenters,...
                            'LbinsEdgesMat', LbinsEdgesMat, 'LbinsCentersMat', LbinsCentersMat,...
                            'BbinsEdgesMat', BbinsEdgesMat, 'BbinsCentersMat', BbinsCentersMat);
    fprintf(1,'repi %d of %d (now:%s reps done:%s)\n',repi,nrep,datestr(now,'HH:MM:SS'),datestr(RepsTime0+(now-RepsTime0)/repi*nrep,'HH:MM:SS'));
  end  % for repi = 1:nrep
else
  pruneidxmat = defvec;
end

if DO_SCZ
  sig0Init = sqrt(1.137301087972745);
  pi1Init  = 0.002835626545709;
  sigbInit = sqrt(6.266466259820954e-05);
  x_fit0 = double([log(sig0Init) logit(pi1Init,0) log(sigbInit)]);
elseif DO_SCZ_SEP2017
  x_fit0 = [0.102200199788046  -5.906567126842933  -4.769029883455596];
elseif DO_BIP
  sig0Init = sqrt(1.050150278415023);
  pi1Init  = 0.002700967051966;
  sigbInit = sqrt(5.514618492733737e-05);
  x_fit0 = double([log(sig0Init) logit(pi1Init,0) log(sigbInit)]);
elseif DO_CAD
  x_fit0 = [-0.0062   -9.4534   -4.3625];
elseif DO_PUTAMEN | DO_ACCUMBENS | DO_AMYGDALA | DO_CAUDATE | DO_HIPPO DO_PALLIDUM | DO_THALAMUS
  x_fit0 = [0.006678697588719  -9.766259426975278  -3.495000445367124];
elseif DO_MDD
  x_fit0 = [0.024518808481480  -4.717954443827099  -6.286133142600587];
elseif DO_MDD2018
  x_fit0 = [0.020619372608694  -5.676514823531979  -5.849798031482836];
elseif DO_HEIGHT
  x_fit0 = [0.209616387618247  -7.413018617825962  -4.223260863579883];
elseif DO_HEIGHT2018
  x_fit0 = [0.4076   -7.0019   -4.1376];
elseif DO_HEIGHT2010
  x_fit0 = [-0.055930295230440  -7.717143877438099  -4.356504535168476];
elseif DO_EXTRAVERSION
  x_fit0 = [0.003856363483978  -4.569455761500322  -6.239843883201345];
elseif DO_NEUROTICISM | DO_OPENNESS
  x_fit0 = [0.0093   -8.0696   -5.2917];
elseif DO_BMI
  x_fit0 = [-0.0643   -8.1985   -4.6307];
elseif DO_CRP
  x_fit0 = [0.0296  -11.0615   -3.2552];
elseif DO_HDL
  x_fit0 = [-0.0133  -10.3655   -3.1566];
elseif DO_LDL
  x_fit0 = [-0.0133  -10.5611   -3.3070];
elseif DO_CD
  x_fit0 = [0.0792   -9.0293   -3.2520];
elseif DO_UC
  x_fit0 = [-0.0133  -10.5611   -3.3070];
elseif DO_TC | DO_TG
  x_fit0 = [-0.0160  -10.1668   -3.5317];
elseif DO_EduYear
    x_fit0 = [0.030717067159987  -6.681322161723175  -5.259367581682628];
elseif DO_ReactionTime | DO_ICV_Enigma2 | DO_VNR | DO_CA | DO_CO
  x_fit0 = [0.003856363483978  -4.569455761500322  -6.239843883201345];
elseif DO_AD
  if AD_INCLUDE_CHR_19_ONLY
    sig0Init = 1.0;
    pi1Init  = 2.4006e-05;
    sigbInit = sqrt(0.008395871966288);
    sigbInit = sqrt(10)*sigbInit;
    x_fit0 = double([log(sig0Init) logit(pi1Init,0) log(sigbInit)]);
  elseif AD_EXCLUDE_CHR_19
    x_fit0 = [0.0143  -10.0707   -4.4405];   % <-- standard
  else
    x_fit0 = [0.0246   -9.2122   -4.1691];
  end
elseif DO_AD2018
  if AD_INCLUDE_CHR_19_ONLY
    sig0Init = 1.0;
    pi1Init  = 2.4006e-05;
    sigbInit = sqrt(0.008395871966288);
    sigbInit = sqrt(10)*sigbInit;
    x_fit0 = double([log(sig0Init) logit(pi1Init,0) log(sigbInit)]);
  elseif AD_EXCLUDE_CHR_19
    x_fit0 = [0.0143  -10.0707   -4.4405];   % <-- standard
  else
    x_fit0 = [0.0157  -14.8885   -2.1143];   % <-- standard
  end
elseif DO_COG
  x_fit0 = [0.0271   -5.8231   -5.4323];
elseif DO_IQ
  x_fit0 = [0.030194147657909  -6.607549637792747  -4.890678287038556];
elseif DO_COG2018 | DO_CTG_INTELLIGENCE_2018
  x_fit0 = [0.098592896715706  -6.158165582764155  -5.164412400047121];
end

paramsTrue = [];
figNum = 1;

argStruct = struct('zmin',qq_y_zmin,...
                   'zmax',qq_y_zmax,...
                   'NONLIN_Z_BINS_MINIMIZATION',nonlin_z_bins_minimization,...
                   'nq',nq,...
                   'qq_y_uprTmp1',qq_y_uprTmp1,...
                   'qq_y_uprTmp2',qq_y_uprTmp2,...
                   'f',f,...
                   'nCausalsPerBlockMax',nCausalsPerBlockMax,...
                   'phenoName',phenoName,...
                   'paramsTrue',paramsTrue,...
                   'outDir',outDir,...
                   'betai',figNum,...
                   'figNum',figNum,...
                   'xIsTrue',false,...
                   'UPDATE_FIGS',false,...
                   'figInfix',figInfix,...
                   'nsnps_from_full_LD_build',nsnps_from_full_LD_build,...
                   'Hbar_from_full_LD_build',Hbar_from_full_LD_build);

 x1 = x_fit0;
 
costfun1 = @(x) causalEffectsModelCost_fourier(x,sumstats,zvec,pruneidxmat,defvec,Hvec,Lvec,r2meanvec,argStruct);
[x_fit1F cost1F] = fminsearch(costfun1,x1,statset('MaxIter',1000,'MaxFunEvals',1000,'Display','iter'));
[costEstF resstructEstF] = causalEffectsModelCost_fourier(x_fit1F,sumstats,zvec,pruneidxmat,defvec,Hvec,Lvec,r2meanvec,argStruct);

resstructEstF.Neff  = Neff;
resstructEstF.pheno = pheno;
fileName=[outDir '/resstructs' phenoName tldInfix nldInfix '.mat'];
save(fileName, 'resstructEstF');
return
