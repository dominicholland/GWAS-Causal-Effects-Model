

% Dominic Holland
% https://www.biorxiv.org/content/early/2018/06/07/133132

% causalEffectsModelCost

function [cost resstruct] = causalEffectsModelCost(x,sumstats,zvec,pruneidxmat,defvec,Hvec,Lvec,r2meanvec,argStruct)

if ~exist('argStruct','var'),  argStruct = struct();
                               argStruct.outDir      = '/space/md10/8/data/holland/genetics/phenos';
end

BIP_REPL_CALCS = false;

zmin                     = argStruct.zmin;
zmax                     = argStruct.zmax;
f                        = argStruct.f;
phenoName                = argStruct.phenoName;
paramsTrue               = argStruct.paramsTrue;
outDir                   = argStruct.outDir;
xIsTrue                  = argStruct.xIsTrue;
figInfix                 = argStruct.figInfix;
nsnps_from_full_LD_build = argStruct.nsnps_from_full_LD_build;
Hbar_from_full_LD_build  = argStruct.Hbar_from_full_LD_build;
UPDATE_FIGS              = argStruct.UPDATE_FIGS;
qq_y_uprTmp1             = argStruct.qq_y_uprTmp1;
qq_y_uprTmp2             = argStruct.qq_y_uprTmp2;
nq                       = argStruct.nq;
minr2  = 0;  if isfield(argStruct,'minr2'),  minr2  = argStruct.minr2; end
h2True = 0;  if isfield(argStruct,'h2True'), h2True = argStruct.h2True; end
betai  = 1;  if isfield(argStruct,'betai'),  betai  = argStruct.betai;  end
figNum = 1;  if isfield(argStruct,'figNum'), figNum = argStruct.figNum; end

% f is the number of SNPs that are represented, on average, by each SNP.
% If n is he total number of SNPs, then n/f is the expected number of independent SNPs.

cost = 0;
resstruct = struct;

siga=1e-100;
pp=0;
b=0;
if length(x)==6
  sig0 = exp(x(1));
  pi1  = logit(x(2),1);
  sigb = exp(x(3));
  siga = exp(x(4));
  pp   = x(5);
  b    = x(6);
elseif length(x)==5
  sig0 = exp(x(1));
  pi1  = logit(x(2),1);
  sigb = exp(x(3));
  siga = exp(x(4));
  pp   = x(5);
elseif length(x)==4
  sig0 = exp(x(1));
  pi1  = logit(x(2),1);
  sigb = exp(x(3));
  siga = exp(x(4));
elseif length(x)==3  % Fit for sig0 and pi1 and sigb
  sig0 = exp(x(1));
  pi1  = logit(x(2),1);
  sigb = exp(x(3));
elseif length(x)==2  % Fit for pi1 and sigb
  sig0 = argStruct.sig0;  % Must supply this separately, not as part of x.  %siga = exp(x(2));       % and fitting for siga
  pi1  = logit(x(1),1);
  sigb = exp(x(2));
elseif length(x)==1  % Fit for sig0
  sig0 = exp(x(1));       % Fitting for sig0
  pi1  = argStruct.pi1;   % Must supply these separately, not as part of x.
  sigb = argStruct.sigb;  % Must supply these separately, not as part of x.
end

fnoffset  = 0;


CHECK_DELTA = false;
if nargout > 1
deltaStep = 0.04;  % 0.1;
deltaMax  = 12;    % 12;
ndelta = 2*floor(deltaMax/deltaStep)+1;  % Odd.
deltaVec = linspace(-deltaMax,deltaMax,ndelta);
                                                                           % deltaVec : Values are bin centers; middle bin centered on 0.
deltaVec_edges = [deltaVec-deltaStep/2 deltaVec(end)+deltaStep/2];         % Values are bin edges;   middle bin centered on 0. length(deltaVec_edges)==length(deltaVec)+1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 DO_FOURIER = true;
 DO_APODIZING = false;

  zvals_disc = sumstats{1}.zvals_disc;     zvals_discColVec = colvec(zvals_disc);
  zstep_orig = zvals_disc(2)-zvals_disc(1);
  
  delvals = zvals_disc;
  upsampfact = 1;
  zvalsF = linspace(delvals(1),-delvals(1),upsampfact*length(delvals)+1); zvalsF = zvalsF(1:end-1);
  
  zstep = zvalsF(2)-zvalsF(1);
  dz = zstep;
  Fs = 1/zstep;
  fvec = -1/2*Fs*zvalsF/zvalsF(1);
  
  f2vec = fvec.^2;
  tmpvec = -2*pi^2*sig0^2*f2vec;
  Fpdfvec0 = exp(tmpvec);  
  FpdfvecInit = ones(size(Fpdfvec0));  % Initialize for accruing by product.
  
  [mv mi] = min(abs(zvalsF));
  if mv~=0
     keyboard % Not implemented
  end
  
  if nargout > 1
    zvals_qq = zvalsF(mi:end);
    logpvals_qq = -log10(2*normcdf(-abs(zvals_qq)));
    hv_z = zvals_qq;
    hv_logp = -log10(2*normcdf(-abs(zvals_qq)));   % <-- overwritten below -- becomes equivalent to hv_logp_fine. See:  "[logqvecHLR hv_logp  logqmatHLR_ci] = GenStats_QQ_plot_withCI(logpvecHLR,hv_z_fine,ci_alpha,f);" below.
    hv_dz = hv_z(2)-hv_z(1);
    hv_z_edges = [hv_z-hv_dz/2 hv_z(end)+hv_dz/2];  % Values are bin edges;   first bin centered on 0. length(hv_z_edges)==length(hv_z)+1;
    
    zvals_fine = linspace(delvals(1),-delvals(1),100000+1); zvals_fine = zvals_fine(1:end-1);
    [mv_fine mi_fine] = min(abs(zvals_fine));
    if mv_fine~=0
      keyboard % Not implemented
    end
    zvals_qq_fine = zvals_fine(mi_fine:end);
    logpvals_qq_fine = -log10(2*normcdf(-abs(zvals_qq_fine)));
    hv_z_fine = zvals_qq_fine;
    hv_logp_fine = -log10(2*normcdf(-abs(zvals_qq_fine)));
    
    hv_dz_fine = hv_z_fine(2)-hv_z_fine(1);
    zstep_fine = hv_dz_fine;
    
    cdfvec_predF_fine = zeros(size(hv_z_fine));

  end
  
  zvals_disc_edges = [zvals_disc-dz/2 zvals_disc(end)+dz/2];       % Values are bin edges;   middle bin centered on 0. length(zvals_discColVec_edges)==length(zvals_discColVec)+1;
  qq_ymax_edge_U = -log10(2*normcdf(-zvals_disc_edges(end)));
  qq_ymax_edge_L =  log10(2*normcdf( zvals_disc_edges(1)));
  dq = -qq_ymax_edge_L/(nq-0.5);
  qq_y_linspace_edges = linspace(dq,-qq_ymax_edge_L,nq+1);
  zvals_disc_nonlin_edges = -norminv(10.^(-qq_y_linspace_edges)/2);
  zvals_disc_nonlin_edges = [-fliplr(zvals_disc_nonlin_edges(1:end)) zvals_disc_nonlin_edges(1:end-1)];
  zvals_disc_nonlin_centers = nan(length(zvals_disc_nonlin_edges)-1,1);
  for i=1:length(zvals_disc_nonlin_centers)
    zvals_disc_nonlin_centers(i) = (zvals_disc_nonlin_edges(i+1)+zvals_disc_nonlin_edges(i))/2;  % zero-centered
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TLD_MAX = 99999999;
AVERAGE_OVER_REPS = true;
nprune = size(sumstats,2);
nreps = 1;
if AVERAGE_OVER_REPS,  nreps = nprune;  fileNameInfixAvg = '_Avg';  end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pdfvec_pred = 0;
pdfvec = 0;
pdfvecAccum = 0;
cdfvec_pred = 0;
cdfvec_predF = 0;
cdfvec = 0;
cdfvecAccum = 0;
time0 = now;

tmp = sumstats{1}.cntmat;
nzvals = size(tmp,1);
nHbins = size(tmp,2);
nLbins = size(tmp,3);
nBbins = size(tmp,4);

tmp = sumstats{1}.r2fracmat2;
nrbins = size(tmp,1);

snps_cntCell        = cell(nHbins, nLbins, nBbins, nreps);
if nargout > 1
  dvals_replCell              = cell(nHbins, nLbins, nBbins, nreps);
  dvals_repl_cntCell          = cell(nHbins, nLbins, nBbins, nreps);
  probDeltaGivenZmat_replCell = cell(nHbins, nLbins, nBbins, nreps);
  pdfDelta_replCell           = cell(nHbins, nLbins, nBbins, nreps);
  pie_0_Multinomial_mat       = nan(nHbins, nLbins, nBbins, nreps);
  pdfZvec_replCell            = cell(nHbins, nLbins, nBbins, nreps);
end

% FOR QQ grid of plots:
qqHLplotsStruct = struct();
qqHLplotsMainCell = cell(nHbins, nLbins, nBbins);

zvals_disc = sumstats{1}.zvals_disc;     zvals_discColVec = colvec(zvals_disc);

dz = zvals_discColVec(2)-zvals_discColVec(1);
zvals_discColVec_edges = [zvals_discColVec-dz/2; zvals_discColVec(end)+dz/2];       % Values are bin edges;   middle bin centered on 0. length(zvals_discColVec_edges)==length(zvals_discColVec)+1;

if nargout > 1
nzvalsPlot = 501;
zvalsMax = 10;
zvalsPlot = linspace(-zvalsMax,zvalsMax,nzvalsPlot);
zvalsPlot = zvalsPlot'; %'
dzPlot = zvalsPlot(2)-zvalsPlot(1);

zvalsPlot_edges = [zvalsPlot-dzPlot/2; zvalsPlot(end)+dzPlot/2];       % Values are bin edges;   middle bin centered on 0. length(zvalsPlot_edges)==length(zvalsPlot)+1;
end

cost = 0;

if ~exist('zmax','var'), zmax = max(zvals_disc); end   % Fit for all z.

zvals_fit = zvals_disc;
edgevec = (zvals_disc(2:end)+zvals_disc(1:end-1))/2;
dedge = edgevec(2)-edgevec(1);
edgevec = [edgevec(1)-dedge edgevec edgevec(end)+dedge];  edgevec = colvec(edgevec);

fprintf(1,'pi1 = %.2e  sig2_0 = %e  sig2_b = %e,  sig2_a = %e, b=%g, pp=%g\n', pi1,sig0^2,sigb^2,siga^2,b,pp);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargout > 1
ci_alpha = 0.05;
qMedian = 0.5;
z2_medianNull = chi2inv(qMedian,1);     % 0.454
figNum_QQwithSubPlots = figNum+1000;
figName_QQwithSubPlots = [num2str(figNum_QQwithSubPlots) ': minr2=' num2str(minr2)];
makeSubplots = true;
plotBinNums = [1, 4, 7, 10];
 if makeSubplots % & (ismember(Hbini,plotBinNums) & ismember(Lbini,plotBinNums)) & betai==1
  if UPDATE_FIGS
   %figure('name',figName_QQwithSubPlots,'NumberTitle','off'); subFig_cnt = 0;
    figure(figNum_QQwithSubPlots); subFig_cnt = 0;
  else
   %figure('name',figName_QQwithSubPlots,'NumberTitle','off'); clf; subFig_cnt = 0;
    figure(figNum_QQwithSubPlots); clf; subFig_cnt = 0;
  end
 end
 logpvec = -log10(normcdf(-abs(zvec))*2);

ivecFinite = find(defvec);
zvecFinite = zvec(ivecFinite);
HvecFinite = Hvec(ivecFinite);
LvecFinite = Lvec(ivecFinite);

lamGC_median_QQobsAvg  = nan(nHbins,nLbins);
lamGC_median_QQpredAvg = nan(nHbins,nLbins);

subFig_lamGC_medianFromQQ_data = nan(nHbins,nLbins);
subFig_lamGC_median_data       = nan(nHbins,nLbins);

lamGC_median_Zobs  = nan(nHbins,nLbins,nreps);
lamGC_mean_Zobs    = nan(nHbins,nLbins,nreps);
lamGC_median_QQobs = nan(nHbins,nLbins,nreps);
lamGC_median_QQpred = nan(nHbins,nLbins,nreps);
lamGC_mean_QQpred   = nan(nHbins,nLbins,nreps);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

HbinsTime0 = now;
if nargout > 1
  cdfvec      = zeros(size(hv_z_fine));
  cdfvec_predF= zeros(size(hv_z));   % Initialize for each new HL bin.
end
for Hbini = 1:nHbins
  LbinsTime0 = now;
  for Lbini = 1:nLbins
    RepsTime0 = now;
    if nargout > 1
      HmeanHL = 0;
      LmeanHL = 0;
      nsnpsHL = 0;
      HminHL  = 0;
      LminHL  = 0;
      HmaxHL  = 0;
      LmaxHL  = 0;
      cdfvecHL      = zeros(size(hv_z_fine));
      cdfvecHL_ci1  = zeros(size(hv_z_fine));
      cdfvecHL_ci2  = zeros(size(hv_z_fine));
      cdfvecHL_predF= zeros(size(hv_z));   % Initialize for each new HL bin.
      cdfvecHL_predF_fine = zeros(size(hv_z_fine));
      for repi = 1:nreps
        ivecR = pruneidxmat(:,repi);
        HbinsEdges = sumstats{repi}.HbinsEdges;
        LbinsEdges = sumstats{repi}.LbinsEdgesMat(Hbini,:);
        if Hbini==nHbins
          ivecH = (Hvec >= HbinsEdges(Hbini)) & (Hvec <= HbinsEdges(Hbini+1));
        else
          ivecH = (Hvec >= HbinsEdges(Hbini)) & (Hvec <  HbinsEdges(Hbini+1));
        end
        if Lbini==nLbins
          ivecL = (Lvec >= LbinsEdges(Lbini)) & (Lvec <= LbinsEdges(Lbini+1));
        else
          ivecL = (Lvec >= LbinsEdges(Lbini)) & (Lvec <  LbinsEdges(Lbini+1));
        end
        ivecHLR = ivecH & ivecL & ivecR;
        
        nsnpsHLR = length(find(ivecHLR));  % This IS the number of pruned SNPs in the HL bin, not twice the number;
        % EQUIVALENTLY: nsnpsHLR = sumstats{repi}.nsnpsHLmat(Hbini,Lbini);
        % NOTE: assuming nBbins==1:   xx=sumstats{repi}.cntmat(:,Hbini,Lbini,1); sum(xx) == 2*nsnpsHLR;
        % For nBbins>1, summing sumstats{repi}.cntmat(:,Hbini,Lbini,Bbini) over Bbini will give 2*nsnpsHLR;
        
        nsnpsFinite = sumstats{repi}.nsnpsFinite;  % This IS the number of pruned SNPs, not twice the number.
        
        if nsnpsHLR==0,  continue;  end   % Otherwise get nan for Hmean.
        fracSnpsHLR = nsnpsHLR/nsnpsFinite;
        nsnpsHL = nsnpsHL + nsnpsHLR;
        
        zdvecHLR = zvec(ivecHLR);
        logpvecHLR = -log10(normcdf(-abs(zdvecHLR))*2);
        
        ci_alpha = 0.05;
        % f is the number of SNPs that are represented, on average, by each SNP.
        % n is he total number of SNPs, so n/f is the expected number of independent SNPs.
        f=10;
        
        [logqvecHLR hv_logp  logqmatHLR_ci] = GenStats_QQ_plot_withCI(logpvecHLR,hv_z_fine,ci_alpha,f);  logqvecHLR = logqvecHLR';  % '
        cdfvecHL = cdfvecHL + 10.^-logqvecHLR;
        cdfvec   = cdfvec   + fracSnpsHLR*10.^-logqvecHLR;
        
        cdfvecHL_ci1 = cdfvecHL_ci1 + 10.^-logqmatHLR_ci(:,1)';  % '
        cdfvecHL_ci2 = cdfvecHL_ci2 + 10.^-logqmatHLR_ci(:,2)';  % '
        
        lamGC_median_Zobs(Hbini,Lbini,repi) = median(zdvecHLR.^2)/z2_medianNull;
        lamGC_mean_Zobs  (Hbini,Lbini,repi) = mean(zdvecHLR.^2);
        
        HmeanHL = HmeanHL + mean(Hvec(ivecHLR));
        LmeanHL = LmeanHL + mean(Lvec(ivecHLR));
        HminHL  = HminHL  + min(Hvec(ivecHLR));
        LminHL  = LminHL  + min(Lvec(ivecHLR));
        HmaxHL  = HmaxHL  + max(Hvec(ivecHLR));
        LmaxHL  = LmaxHL  + max(Lvec(ivecHLR));
      end  % for repi = 1:nreps
      nsnpsHL = floor(nsnpsHL/nreps);
      HmeanHL = HmeanHL/nreps;
      LmeanHL = LmeanHL/nreps;
      HminHL  = HminHL/nreps;
      LminHL  = LminHL/nreps;
      HmaxHL  = HmaxHL/nreps;
      LmaxHL  = LmaxHL/nreps;
      cdfvecHL = cdfvecHL/nreps;
      cdfvecHL_ci1 = cdfvecHL_ci1/nreps;
      cdfvecHL_ci2 = cdfvecHL_ci2/nreps;
    end % if nargout > 1
    
    for Bbini = 1:nBbins
      for repi = 1:nreps
        
        Fpdfvec = FpdfvecInit;
        
        nsnpsFiniteR = sumstats{repi}.nsnpsFinite;
        nsnpsHLR     = sumstats{repi}.nsnpsHLmat(Hbini,Lbini);
        nsnpsHLBR    = sumstats{repi}.nsnpsHLBmat(Hbini,Lbini,Bbini);
        
        if isnan(nsnpsHLBR) | (isfinite(nsnpsHLBR) & nsnpsHLBR==0),  continue;  end                           % No data (no SNPs) from which to estimate data parameters (H, LD).
        
        fracSnpsHLR  = nsnpsHLR/nsnpsFiniteR;
        fracSnpsHLBR = nsnpsHLBR/nsnpsHLR;
        
        snps_cnt = sumstats{repi}.cntmat(:,Hbini,Lbini,Bbini);   % <--- TWICE (due to symmetry in using histmean_dh()) the total number of SNPs in each z-bin defined by zvals_discColVec_edges.
        snps_cntCell{Hbini, Lbini, Bbini, repi} = snps_cnt;      % Why bother with this?
	% NOTE: sum(snps_cnt) == 2*nsnpsHLBR;                    % Twice the number of SNPs -- dee histmean_dh();
        
        nLDval       = sumstats{repi}.nLDmat(Hbini,Lbini,Bbini); % Average total number of SNPs in the LD blocks of SNPs in (Hbini,Lbini,Bbini)-window.
        Hval         = sumstats{repi}.Hmat(Hbini,Lbini,Bbini);
        Lval         = sumstats{repi}.Lmat(Hbini,Lbini,Bbini);
        
        if isfield(sumstats{repi}, 'Nmat')
          if ~isempty(sumstats{repi}.Nmat)
            Neff     = floor(sumstats{repi}.Nmat(Hbini,Lbini,Bbini));
          else
            Neff     = double(sumstats{repi}.Neff);
          end
        else
          Neff       = double(sumstats{repi}.Neff);
        end
        
        nr2fracWvec = sumstats{repi}.r2fracmat2(:,Hbini,Lbini,Bbini); % Vector of length w, giving fractions of SNPs in the LD block that are in the w r^2 windows: sum(nr2fracWvec)==1;
        HhistWvec   = sumstats{repi}.Hhistmat2(:,Hbini,Lbini,Bbini);  % Vector of length w, giving mean heterozygosities in the LD block that are in the w r^2 windows;
        
       %pi1val = 1-(1-pi1)^nLDval;
        pi1val = 1-(1-(pi1+pp*Lval))^nLDval;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % CALCULATE pdf(zd)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for rbini = 1:nrbins
          r2mean = r2meanvec(rbini);
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          nri = floor(nr2fracWvec(rbini)*nLDval);  % Number of SNPs in LD-bin rbini.
          Hri  = HhistWvec(rbini);                 % Mean heterozygosity of SNPs in LD-bin rbini.
          if ~nri | isnan(Hri),  continue;    end
          tmpvec = -2*pi^2*Neff*Hri*r2mean*sigb^2*f2vec;
          FpdfvecTmp = (pi1*exp(tmpvec) + (1-pi1)).^nri;
          Fpdfvec = Fpdfvec.*FpdfvecTmp;
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end    % for rbini = 1:nrbins
        
          if DO_APODIZING
            % CHEBWIN(N,R) returns the N-point Chebyshev window with R decibels of
            % relative sidelobe attenuation. If omitted, R is set to 100 decibels.
            %apovec = rowvec(rowvec(hamming(length(zvalsF)+1)).^1); 
            attenuation_dB = 160;  % 160;
            apovec = rowvec(chebwin(length(zvalsF)+1,attenuation_dB)); % Need sufficient sidelobe suppression to avoid "wrap"
            apovec = apovec(1:end-1);
            pi0 = (1-pi1)^nLDval;
            Fpdfvec = pi0+apovec.*(Fpdfvec-pi0);
          end
          Fpdfvec = Fpdfvec0.*Fpdfvec;
          
          pdfvec_predRF = max(0,real(ifftshift(ifft(fftshift(Fpdfvec)))));
         %figure; clf; plot(zvals_disc, log10(pdfvec_predRF));
         %pdfvec_predRF = pdfvec_predRF/(sum(pdfvec_predRF)*zstep)*(zstep/zstep_orig);    % Should have sum(pdfvec_predRF*dz) == 1    SEE BELOW
          
          if nargout > 1
            qqvec_predF = flip(cumsum(flip([pdfvec_predRF(mi) 2*pdfvec_predRF(mi+1:end)]))*zstep);
            qqvec_predF = qqvec_predF/qqvec_predF(1);
          end
          
          ivec = isfinite(pdfvec_predRF);
          imin=1;
          imax=max(find(ivec));
          bufferLen = 0;
          if 1   % handeling ringing and loss of resolution for low H pdfvec_predRF...
          izeroAll=find(pdfvec_predRF==0);
          if ~isempty(izeroAll)
            isubmin = find(izeroAll<=mi,1,'last');
            isubmax = find(izeroAll>=mi,1);
            if isubmax-isubmin ~= 1,  keyboard;  end
            imin = izeroAll(isubmin);
            imax = izeroAll(isubmax);
            bufferLen = 10;  % 1;
            ivec(1:imin+bufferLen)   = false;
            ivec(imax-bufferLen:end) = false;
          end
          end
          
          ivec = ivec & log10(pdfvec_predRF)>-14;
          ivec=colvec(ivec);
          
          pdfvec_predRF_norm = zeros(size(pdfvec_predRF));
          pdfvec_predRF_norm(ivec) = pdfvec_predRF(ivec)/(sum(pdfvec_predRF(ivec))*zstep)*(zstep/zstep_orig);    % Should have sum(pdfvec_predRF_norm*dz) == 1
          pdfvec_predRF = pdfvec_predRF_norm;
          
          imax=max(find(ivec));
          
          if nargout > 1
            zvals_qq_reduced = zvalsF(mi:imax-bufferLen);
            icdfmax = length(zvals_qq_reduced);  % == imax-bufferLen+1-mi;
            
            indFine = find(zvals_qq_fine<zvals_qq_reduced(end),1,'last');
            pdfvec_predRF_fine = interp1(zvals_qq_reduced, pdfvec_predRF(mi:imax-bufferLen), zvals_qq_fine(1:indFine));
            qqvec_predF_fine = flip(cumsum(flip([pdfvec_predRF_fine(1) 2*pdfvec_predRF_fine(2:end)]))*zstep_fine);
            cdfvec_predF_fine(1:indFine)   = cdfvec_predF_fine(1:indFine)   + fracSnpsHLBR*fracSnpsHLR*qqvec_predF_fine;
            cdfvecHL_predF_fine(1:indFine) = cdfvecHL_predF_fine(1:indFine) + fracSnpsHLBR*            qqvec_predF_fine;  % CDF for current HL bin. Accumulate over all nreps (and Bbins). If bBbins==1, fracSnpsHLBR==1;
            
            qqvec_predF = flip(cumsum(flip([pdfvec_predRF(mi) 2*pdfvec_predRF(mi+1:imax-bufferLen)]))*zstep);
            
            cdfvecHLBR_predF = qqvec_predF;
            cdfvecHL_predF(1:icdfmax)   = cdfvecHL_predF(1:icdfmax) + fracSnpsHLBR*            cdfvecHLBR_predF;  % CDF for current HL bin. Accumulate over all nreps (and Bbins). If bBbins==1, fracSnpsHLBR==1;
            cdfvec_predF(1:icdfmax)     = cdfvec_predF(1:icdfmax)   + fracSnpsHLBR*fracSnpsHLR*cdfvecHLBR_predF;  % With H and L bins, overall CDF will have contributions from each HL bin. Accumulate over all nreps (and Bbins)..
          end
        
        % When FITTING, restrict to region being fit. When not fitting, just keep going.
        if nargout <= 1
          ivecNarrowz = abs(zvals_discColVec) >= zmin & abs(zvals_discColVec) <= zmax;
          ivec = ivec & ivecNarrowz;
          if ~length(find(ivec)),  continue;  end
                    
          % NOTE: mnpdfln(countvec,probvec) requires sum(probvec) == 1 precicely; 0.999999999993455 won''t do.
          
          pdfvec_prior_z = pdfvec_predRF(ivec);
          
          if length(find(pdfvec_prior_z < 0)),  keyboard;  end
                    
          probvec = pdfvec_prior_z*dz;               % prior prob for z-scores (pdf(z) for SNPs in (Hbini,Lbini,Bbini)-window) in each dz element between zmin and zmin; sum(probvec) = 1;
          sum_probvec = sum(probvec);
          
          % zmin > 0, guaranteed to have sum(probvec) < 1;
          % Be careful when setting zmin > 0 !
          if zmin==0 & sum_probvec < 0.95,  fprintf(1,'sum(probvec) = %f\n', sum(probvec));  end
          
          probvec  = rowvec(probvec/sum(probvec));   % Make sure sum(probvec) is PRECICELY 1.
          countvec = rowvec(snps_cnt(ivec));         % sum(countvec)is TWICE the number of actual SNPs -- see +/- symmetry used in employing histmean_dh();
                                                     % countvec is the number of SNPs in each dz element between zmin and zmin;
          
          zvalsTmp = zvals_discColVec(ivec);
          
          if qq_y_uprTmp1
            z_uprTmp1 = -norminv(10.^(-qq_y_uprTmp1)/2);
            izUprTmp1 = find(zvalsTmp< z_uprTmp1,1,'last');
            izLwrTmp1 = find(zvalsTmp>-z_uprTmp1,1,'first');
            probTmp1  = sum(probvec(izLwrTmp1:izUprTmp1));
            countTmp1 = sum(countvec(izLwrTmp1:izUprTmp1));
          end
          
          z_uprTmp2= -norminv(10.^(-qq_y_uprTmp2)/2);
          if z_uprTmp2 < zvalsTmp(end)
            izUprTmp2= find(zvalsTmp< z_uprTmp2,1,'last');
            izLwrTmp2= find(zvalsTmp>-z_uprTmp2,1,'first');
            probTmp2Lwr = sum(probvec(1:izLwrTmp2));
            probTmp2Upr = sum(probvec(izUprTmp2:end));
            countTmp2Lwr = sum(countvec(1:izLwrTmp2));
            countTmp2Upr = sum(countvec(izUprTmp2:end));
            
            if qq_y_uprTmp1
              probvecCoarse  = [probTmp2Lwr  probvec(izLwrTmp2+1:izLwrTmp1-1)  probTmp1  probvec(izUprTmp1+1:izUprTmp2-1)  probTmp2Upr];
              countvecCoarse = [countTmp2Lwr countvec(izLwrTmp2+1:izLwrTmp1-1) countTmp1 countvec(izUprTmp1+1:izUprTmp2-1) countTmp2Upr];
            else
              probvecCoarse  = [probTmp2Lwr  probvec(izLwrTmp2+1:izUprTmp2-1)  probTmp2Upr];
              countvecCoarse = [countTmp2Lwr countvec(izLwrTmp2+1:izUprTmp2-1) countTmp2Upr];
            end
          else
            if qq_y_uprTmp1
              probvecCoarse  = [probvec(1:izLwrTmp1-1)  probTmp1  probvec(izUprTmp1+1:end)];
              countvecCoarse = [countvec(1:izLwrTmp1-1) countTmp1 countvec(izUprTmp1+1:end)];
            else
              probvecCoarse  = probvec;
              countvecCoarse = countvec;
            end
          end
          
          % mnpdfln() fails (returns Inf) if the arrays are too long and/or extreme (numerical resolution issue?).
          % So, to get useful (and reasonable) values, shrink the arrays (and renormalize probvecCoarse)...
          tmp = -mnpdfln(countvecCoarse,probvecCoarse);
          if ~isfinite(tmp)
            countvecCoarseTmp = countvecCoarse;
            probvecCoarseTmp  = probvecCoarse;
            
            keep_going = true;
            while keep_going
              lenTmp = length(countvecCoarseTmp);
              if lenTmp < 30,  keyboard;  end
              lenreduce = int32(floor(lenTmp/10));
              countvecCoarseTmp = countvecCoarseTmp(lenreduce:end-lenreduce);
              probvecCoarseTmp  = probvecCoarseTmp(lenreduce:end-lenreduce);  probvecCoarseTmp = probvecCoarseTmp/sum(probvecCoarseTmp);
              tmp = -mnpdfln(countvecCoarseTmp,probvecCoarseTmp);
              if isfinite(tmp),  keep_gooing = false;  end
              keyboard
            end
          end
          
          sf = 1;
          cost = cost + sf*(tmp);
          
        end % if nargout <= 1
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
      end    % END  for repi
    end      % END  for Bbini
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if nargout > 1
      cdfvecHL_predF = cdfvecHL_predF/nreps;  % Accumulated and averaged over reps.
      cdfvecHL_predF_fine = cdfvecHL_predF_fine/nreps;  % Accumulated and averaged over reps.
      
      fprintf(1,'B: %g\n', cdfvecHL_predF(1));
      
      logqvecHL      = colvec(-log10(cdfvecHL));  % qqvecHL==logqvecHL;
      logqvecHL_pred = colvec(-log10(cdfvecHL_predF_fine));
     %hv_logp = logpvals_qq;
      logqvecHL_ci1 = colvec(-log10(cdfvecHL_ci1));
      logqvecHL_ci2 = colvec(-log10(cdfvecHL_ci2));
      
      % Calculate Lambda_GC from QQ plots...
      minNumSNPsForSubplot = 50;
      if nsnpsHL >= minNumSNPsForSubplot   % Need actual data to calculate this stuff!
        % These should be fairly consistent with
        % mean(lamGC_median_QQobs,3)
        % and
        % mean(lamGC_median_QQpred,3)
        % Also,  lamGC_median_QQpredAvg(1,1)  should be fairly close to  sig0^2;
        lamGC_median_QQobsAvg (Hbini,Lbini) = lamGCfromQQ(logqvecHL,     hv_logp_fine);
        lamGC_median_QQpredAvg(Hbini,Lbini) = lamGCfromQQ(logqvecHL_pred,hv_logp_fine);
      end
      
      qqPlotStep = 100;
      
      if makeSubplots & (ismember(Hbini,plotBinNums) & ismember(Lbini,plotBinNums)) & betai==1
      % Subplots here...
      subFig_cnt = subFig_cnt + 1;
      xmax =  7; %  7
      ymax = 25; % 16
      indMaxPlot = find(logqvecHL==max(logqvecHL(isfinite(logqvecHL))),1,'last');
      ymax = max(hv_logp(indMaxPlot), 8);
      
      figure(figNum_QQwithSubPlots); subplot(length(plotBinNums),length(plotBinNums),subFig_cnt); hold on;

     %qqHLplotsStruct = struct();
      qqHLplotsStruct.subplotDimx = length(plotBinNums);
      qqHLplotsStruct.subplotDimy = length(plotBinNums);
      qqHLplotsStruct.subplotCount = subFig_cnt;
      qqHLplotsStruct.xmax = xmax;
      qqHLplotsStruct.ymax = ymax;
      qqHLplotsStruct.plotBinNums = plotBinNums;
      
      if UPDATE_FIGS
        figure(figNum_QQwithSubPlots); subplot(length(plotBinNums),length(plotBinNums),subFig_cnt); hold on;
        hModel    = plot(logqvecHL_pred(1:qqPlotStep:end),hv_logp_fine(1:qqPlotStep:end),'k-','LineWidth',1); %hold on;
      else
        figure(figNum_QQwithSubPlots); subplot(length(plotBinNums),length(plotBinNums),subFig_cnt); hold on;
        hExpected = plot([0 10*xmax],[0 10*xmax],'k:'); hold on;
        hData     = plot(logqvecHL(1:qqPlotStep:end), hv_logp_fine(1:qqPlotStep:end),'-','LineWidth',1); hold on;  % 3
        hData_ci1 = plot(logqvecHL_ci1(1:qqPlotStep:end), hv_logp(1:qqPlotStep:end),'k--','LineWidth',1); hold on;
        hData_ci2 = plot(logqvecHL_ci2(1:qqPlotStep:end), hv_logp(1:qqPlotStep:end),'k--','LineWidth',1); hold on;
        hModel    = plot(logqvecHL_pred(1:qqPlotStep:indMaxPlot),hv_logp(1:qqPlotStep:indMaxPlot),'-','LineWidth',1); hold on;  % 5
        
        qqHLplotsStruct.DataX = logqvecHL(1:qqPlotStep:end);
        qqHLplotsStruct.DataY = hv_logp_fine(1:qqPlotStep:end);
        qqHLplotsStruct.ci1X  = logqvecHL_ci1(1:qqPlotStep:end);
        qqHLplotsStruct.ci1Y  = hv_logp(1:qqPlotStep:end);
        qqHLplotsStruct.ci2X  = logqvecHL_ci2(1:qqPlotStep:end);
        qqHLplotsStruct.ci2Y  = hv_logp(1:qqPlotStep:end);
        qqHLplotsStruct.ModelX = logqvecHL_pred(1:qqPlotStep:indMaxPlot);
        qqHLplotsStruct.ModelY = hv_logp(1:qqPlotStep:indMaxPlot);
      end
      xlim([0 xmax]); ylim([0 ymax]);
      
      if ~UPDATE_FIGS
      set(gca,'FontSize',16)             % 12 set the font size of everything, including the tick labels
      if Lbini == 1 & Hbini == nHbins, hx=xlabel('Empirical -log_1_0(q)'); end % set(hx,'FontSize',20);  end
      if Lbini == 1 & Hbini == 1,      hy=ylabel('Nominal -log_1_0(p)');   end % set(hy,'FontSize',20);  end
      ht=title(sprintf('H=[%.2f %.2f], TLD=[%d %d] %.2f', HminHL, HmaxHL,round(LminHL),round(LmaxHL),minr2));       % set(ht,'FontSize',14);
      
      qqHLplotsStruct.HminHL = HminHL;
      qqHLplotsStruct.HmaxHL = HmaxHL;
      qqHLplotsStruct.LminHL = round(LminHL);
      qqHLplotsStruct.LmaxHL = round(LmaxHL);
      qqHLplotsStruct.phenoName = phenoName(2:end);
      
      paramFontSize = 24;  %24;
      if nsnpsHL >= minNumSNPsForSubplot
        xtext = [0.5];
        ytext = [ymax*(7/12)];
        str = ['$$\hat{\lambda}_{model}=$$' num2str(lamGC_median_QQpredAvg(Hbini,Lbini),'%.2f')];
        atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
        xtext = [0.5];
        ytext = [ymax*(4/12)];
        str = ['$$\hat{\lambda}_{data}=$$' num2str(lamGC_median_QQobsAvg(Hbini,Lbini),'%.2f')];
        atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
        
        qqHLplotsStruct.lambda_model = lamGC_median_QQpredAvg(Hbini,Lbini);
        qqHLplotsStruct.lambda_data = lamGC_median_QQobsAvg(Hbini,Lbini);
      end
      
      qqHLplotsStruct.nsnpsHL = nsnpsHL;
      qqHLplotsMainCell{Hbini, Lbini, Bbini} = qqHLplotsStruct;
      
      if nsnpsHL>1e4
        str = ['n=' num2str(nsnpsHL,'%.1e')];
      else
        str = ['n=' num2str(nsnpsHL,'%d')];
      end
      if Lbini == 1 & Hbini == 1
        legendString = [{['Data']}, {['Model']}, {['Expected']}];  % 'Expected under null'
        hLegend = legend([hData hModel hExpected], legendString, 'Location', 'NorthWest');
        set(hLegend,'FontSize',paramFontSize);  % 12
        legend boxoff;
        xtext = [4.0];
        ytext = [ymax*(2/12)];
        atext = text(xtext,ytext,str,'FontSize',paramFontSize);  % 14
      else
        xtext = [4.0];
        ytext = [ymax*(2/12)];
        atext = text(xtext,ytext,str,'FontSize',paramFontSize);  % 14
      end
      set(gca, 'box','off');
      end % if ~UPDATE_FIGS
      drawnow;
      end % if (nHbins<=5 & nLbins<=5) % if betai==1
      
      % Save for plotting shortly...
      if Hbini==1 & Lbini==1
        H1L1_logqvecAccum = logqvecHL(1:qqPlotStep:end);
        H1L1_logqvecAccum_ci1 = logqvecHL_ci1(1:qqPlotStep:end);
        H1L1_logqvecAccum_ci2 = logqvecHL_ci2(1:qqPlotStep:end);
        H1L1_logqvec_pred = logqvecHL_pred(1:qqPlotStep:end);
        H1L1_hv_logp      = hv_logp(1:qqPlotStep:end);
        H1L1_nsnps        = nsnpsHL;
        H1L1_Hmean0       = HmeanHL;
        H1L1_Lmean0       = round(LmeanHL);
        H1L1_HminHL       = HminHL;
        H1L1_HmaxHL       = HmaxHL;
        H1L1_LminHL       = round(LminHL);
        H1L1_LmaxHL       = round(LmaxHL);
        H1L1_lambda_model = lamGC_median_QQpredAvg(Hbini,Lbini);
        H1L1_lambda_data  = lamGC_median_QQobsAvg(Hbini,Lbini);
      end
      %%%%%%%%%%%%%%%%%%%%%%%%%%%
      
      fprintf(1,'Lbini %d of %d done (now=%s done=%s)\n',Lbini,nLbins,datestr(now,'dddd HH:MM:SS'),datestr(LbinsTime0+(now-LbinsTime0)*nLbins/Lbini,'dddd HH:MM:SS'));
    end  % if nargout > 1
  end    % for Lbini = 1:nLbins
  if nargout > 1, fprintf(1,'Hbini %d of %d done (now=%s done=%s)\n',Hbini,nHbins,datestr(now,'dddd HH:MM:SS'),datestr(HbinsTime0+(now-HbinsTime0)*nHbins/Hbini,'dddd HH:MM:SS')); end
end      % for Hbini = 1:nHbins

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargout > 1
  cdfvec      = cdfvec     /nreps;
  cdfvec_predF= cdfvec_predF/nreps;
  
  fprintf(1,'C: %g\n', cdfvec_predF(1));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if 1 & nargout > 1
  hold off;
  h2True_Est = 0;
  if UPDATE_FIGS & xIsTrue
    pi1Tru   = pi1;
    sig2bTru = sigb^2;
    h2True_Est    = Hbar_from_full_LD_build*sig2bTru*floor(pi1Tru*nsnps_from_full_LD_build);
  end
  
  if betai==1
  figNum_H1L1  = figNum+2000;
  figName_H1L1 = [num2str(figNum_H1L1) ': minr2=' num2str(minr2)];
  if UPDATE_FIGS
    figure(figNum_H1L1);
  else
    figure(figNum_H1L1); clf;
  end
  paramFontSize = 24;
  xmax =  7; %  7
  ymax = 7;  % 16
  xymax = max(7,max(xmax, ymax));
  if UPDATE_FIGS
    figure(figNum_H1L1);
    hModel    = plot(H1L1_logqvec_pred,H1L1_hv_logp,'g:','LineWidth',5); %hold on;
  else
    figure(figNum_H1L1);
    hExpected = plot([0 xymax],[0 xymax],'k:'); hold on;
    hData     = plot(H1L1_logqvecAccum,    H1L1_hv_logp,'-',  'LineWidth',3); hold on;
    hData_ci1 = plot(H1L1_logqvecAccum_ci1,H1L1_hv_logp,'k--','LineWidth',3); hold on;
    hData_ci2 = plot(H1L1_logqvecAccum_ci2,H1L1_hv_logp,'k--','LineWidth',3); hold on;
    hModel    = plot(H1L1_logqvec_pred,    H1L1_hv_logp,':',  'LineWidth',5); hold on;
  end
  xlim([0 xmax]); ylim([0 ymax]);
  
  if ~UPDATE_FIGS
  figure(figNum_H1L1);
  set(gca,'FontSize',paramFontSize)             % set the font size of everything, including the tick labels
  hx=xlabel('Empirical -log_1_0(q)'); set(hx,'FontSize',paramFontSize);
  hy=ylabel('Nominal -log_1_0(p)');   set(hy,'FontSize',paramFontSize);
  ht=title(sprintf('H=[%.2f %.2f], TLD=[%d %d] %.2f', H1L1_HminHL, H1L1_HmaxHL,H1L1_LminHL,H1L1_LmaxHL, minr2));
  
  xtext = [0.25];
  ytext = [3.5];
  str = ['$$\hat{\lambda}_{model}=$$' num2str(H1L1_lambda_model,'%.2f')];
  atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  xtext = [0.25];
  ytext = [2.5];
  str = ['$$\hat{\lambda}_{data}=$$' num2str(H1L1_lambda_data,'%.2f')];
  atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  
  if H1L1_nsnps>1e4
    str = ['$n_{snp}=$' num2str(H1L1_nsnps,'%.1e')];
  else
    str = ['$n_{snp}=$' num2str(H1L1_nsnps,'%d')];
  end
  legendString = [{['Data']}, {['Model']}, {['Expected']}];  % 'Expected under null'
  hLegend = legend([hData hModel hExpected], legendString, 'Location', 'NorthWest');
  set(hLegend,'FontSize',paramFontSize);
  legend boxoff;
  xtext = [0.25];
  ytext = [4.5];
  atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  set(gca, 'box','off');
  end % if ~UPDATE_FIGS
  
  infix = '';
  if xIsTrue
    figFileName = sprintf('%s/qq_H1L1%s_pi1_1em%d_h2_p%d_betai_%d%s.eps',    outDir, figInfix, int8(-log10(pi1Tru)), int8(10*h2True), betai, infix);
  else
    figFileName = sprintf('%s/qq_H1L1%s%s%s.eps', outDir, phenoName, figInfix, infix);
  end
  fprintf(1, 'Writing %s...\n', figFileName);
  saveas(gcf,figFileName,'epsc');
  disp('done')
  end  % if betai==1
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if nargout > 1
dgreen1 = [0.0   200/256  0.0];  dgreen  = [0.0   0.6  0.0];
yellow1 = [1.0   0.9      0.2];
yellow1 = [1.0   0.8      0.2];  dyellow = [1.0   0.7  0.2];
lblue6  = [0.4   0.6      1.0];  dblue   = [0.0   0.0  0.45];  dblue1  = [0.0   0.0  0.8];  blue  = [0.0   0.0  1.0];
lred    = [1     0.25  0.25];    dred    = [0.6   0.0  0.0];
lred    = [1     0.35  0.35];    dred1   = [0.7   0.0  0.0];

black   = [0.0   0.0   0.0];
indigo  = [0.5 0   1];
violet  = [0.3 0   1];

cdfvecAccum     = 0;
cdfvecAccum_ci1 = 0;
cdfvecAccum_ci2 = 0;
ci_alpha        = 0.05;
logpvec = -log10(normcdf(-abs(zvec))*2);


for repi = 1:nreps
  ivecRepi = pruneidxmat(:,repi) & defvec;
  nsnpsFinite = length(find(ivecRepi));
  
  [logqvecRepi hv_logpRepi  logqmat_ciRepi] = GenStats_QQ_plot_withCI(logpvec(ivecRepi),hv_z_fine,ci_alpha,f); 
  
  cdfvecAccum     = cdfvecAccum     + 10.^-logqvecRepi;          % <----- Alternatively can be done as above (cdfvec) using fracSnpsHLR.
  cdfvecAccum_ci1 = cdfvecAccum_ci1 + 10.^-logqmat_ciRepi(:,1);
  cdfvecAccum_ci2 = cdfvecAccum_ci2 + 10.^-logqmat_ciRepi(:,2);
end

cdfvecAccumA = cdfvecAccum/nreps; 
cdfvec_predA = cdfvec_predF_fine/nreps;

% max(cdfvecAccumA)  and  max(cdfvec_predA)  should be almost precicely 1
if max(cdfvecAccumA)<0.975 | max(cdfvec_predA)<0.95,  keyboard;  end

cdfvecAccumB = cdfvecAccumA/max(cdfvecAccumA);
cdfvec_predB = cdfvec_predA/max(cdfvec_predA);

qqvecAccum   = -log10(cdfvecAccumB);
logqvecAccum = qqvecAccum;
logqvec_pred = -log10(cdfvec_predB);

finiteInds = isfinite(cdfvecAccum_ci1);
cdfvecAccum_ci1A = cdfvecAccum_ci1/nreps;
cdfvecAccum_ci1B = cdfvecAccum_ci1A/max(cdfvecAccum_ci1A(finiteInds));
qqvecAccum_ci1   = -log10(cdfvecAccum_ci1B);
logqvecAccum_ci1 = qqvecAccum_ci1;

finiteInds = isfinite(cdfvecAccum_ci2);
cdfvecAccum_ci2A = cdfvecAccum_ci2/nreps;
cdfvecAccum_ci2B = cdfvecAccum_ci2A/max(cdfvecAccum_ci2A(finiteInds));
qqvecAccum_ci2   = -log10(cdfvecAccum_ci2B);
logqvecAccum_ci2 = qqvecAccum_ci2;

figNum_QQplot = figNum;
figName_QQplot = [num2str(figNum_QQplot) ': minr2=' num2str(minr2)];

if UPDATE_FIGS
  figure(figNum_QQplot); hold on;
else
  figure(figNum_QQplot); clf;
  hExpected = plot([0 7],[0 7],'k:'); hold on;
  ht=title(phenoName(2:end)); set(ht,'FontSize',24);  % This needs to come after plot().
end

%view([0   90]);  % default

transparencyLevel=0.5;

indsCI1 = find(isfinite(logqvecAccum_ci1));
indsCI2 = find(isfinite(logqvecAccum_ci2));
ci1 = logqvecAccum_ci1(indsCI1);
ci2 = logqvecAccum_ci2(indsCI2);

y1 = hv_logp_fine(indsCI1);
y2 = hv_logp_fine(indsCI2);

indMax12 = min(length(ci1), length(ci2));

if ~UPDATE_FIGS
  figure(figNum_QQplot);
  [jbFileHandleSwap, jbMsgSwap] = jbfill(y1(1:100:indMax12), ci1(1:100:indMax12)', ci2(1:100:indMax12)',lblue6, 'k', 1, transparencyLevel); hold on;
  set(jbFileHandleSwap,'LineStyle','none');
  hData     = plot(hv_logp_fine(1:100:indMax12), logqvecAccum(1:100:indMax12),'-','Color', violet,'LineWidth',1); hold on;  % 3
  
  data_logp =  hv_logp_fine(1:100:indMax12);
  data_logq =  logqvecAccum(1:100:indMax12);
  data_ci1 = ci1(1:100:indMax12)'; % '
  data_ci2 = ci2(1:100:indMax12)'; % '
end

max_ind = indMax12;
 
if ~UPDATE_FIGS
  figure(figNum_QQplot);
  hModel    = plot(hv_logp_fine(1:100:max_ind),logqvec_pred(1:100:max_ind),'-', 'Color', dyellow,'LineWidth',1); hold on;  % 5
  
  modelFit_logp = hv_logp_fine(1:100:max_ind);
  modelFit_logq = logqvec_pred(1:100:max_ind);
else
  figure(figNum_QQplot); hold on;
  hModel    = plot(hv_logp(1:100:max_ind),logqvec_pred(1:100:max_ind),'-', 'Color', 'g','LineWidth',1); hold on;      % 5
  modelTru_logp  = hv_logp(1:100:indMax12);
  modelTru_logq  = logqvec_pred(1:100:indMax12);
end
  model_logp = hv_logp_fine(1:100:max_ind);  % hv_logp same as hv_logp_fine.
  model_logq = logqvec_pred(1:100:max_ind);
  
  ylim1 = 0;
  ylim2 = 7;
  xlim1 = 0;
  xlim2 = 20;
  figure(figNum_QQplot);
  ylim([ylim1 ylim2]); xlim([xlim1  xlim2]);
  
  lamGC_median_QQpredNet = lamGCfromQQ(logqvec_pred',hv_logp_fine);  %'
  paramFontSize = 24;
if ~UPDATE_FIGS
  figure(figNum_QQplot);
  set(gca, 'box','off');
  view([90 -90]);
  set(gca,'FontSize',24)             % set the font size of everything, including the tick labels
  hx=ylabel('Empirical -log_1_0(q)'); set(hx,'FontSize',24);
  hy=xlabel('Nominal -log_1_0(p)');   set(hy,'FontSize',24);
  
  legendString = [{['Data']}, {['Model']}, {['Expected']}];  % 'Expected under null'
  hLegend = legend([hData hModel hExpected], legendString, 'Location', 'NorthWest');
  set(hLegend,'FontSize',20);
  legend boxoff;
  
  % Calculate Lambda_GC from QQ plots...
  lamGC_median_QQobsNet  = lamGCfromQQ(logqvecAccum,hv_logp_fine);
  
  lamGC_median_ZNetVec = nan(1,nreps);
  for repi = 1:nreps
    lamGC_median_ZobsNetVec(repi) = median(zvec(pruneidxmat(:,repi)).^2)/chi2inv(0.5,1);
  end
  lamGC_median_ZobsNet = mean(lamGC_median_ZobsNetVec);
  
  figure(figNum_QQplot);
  paramFontSize = 24;
  ytext = [0.25];
  xtext = [5.25*xlim2/10];
  str = ['$$\hat{\lambda}_{model}=$$' num2str(lamGC_median_QQpredNet,'%.3f')];
  atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  ytext = [0.25];
  xtext = [4.25*xlim2/10];
  str = ['$$\hat{\lambda}_{data}=$$' num2str(lamGC_median_QQobsNet,'%.3f')];
  atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  
  pi1Est = pi1;
  sig2bEst = sigb^2;
  sig2bEst = sigb^2;
  nsnpsTotalDefvec = length(find(defvec));
  nsnpsTotalAll    = length(defvec);
  HbarReps  = 0;
  nsnpsTotalReps = 0;
  for repi=1:nreps
    ivecRepi = pruneidxmat(:,repi) & defvec;
    HbarReps = HbarReps + mean(Hvec(ivecRepi));
    nsnpsTotalReps = nsnpsTotalReps + length(find(ivecRepi));
  end
  nsnpsTotalReps = floor(nsnpsTotalReps/nreps);
  HbarReps    = HbarReps/nreps;
  HbarDefvec  = mean(Hvec(defvec));
  HbarAllSNPs = mean(Hvec(isfinite(Hvec)));  % <-- This is what is used in the simulation setup.
  
  Hbar       = Hbar_from_full_LD_build;
  nsnpsTotal = nsnps_from_full_LD_build;
  
  if xIsTrue
    numCausalSNPsTru = floor(pi1Tru*nsnpsTotal);
    sigb2TotalTru    = pi1Tru*sig2bTru;
  end
  numCausalSNPsEst = floor(pi1Est*nsnpsTotal);
  sigb2TotalEst    = pi1Est*sig2bEst;
  
  phenotypicVarianceExplainedPerCausalSNP = Hbar*sig2bEst;
  phenotypicVarianceExplainedPerTotalSNP  = Hbar*sigb2TotalEst;
  h2Est = phenotypicVarianceExplainedPerCausalSNP*numCausalSNPsEst;
  
  if xIsTrue
    phenotypicVarianceExplainedPerCausalSNPTruEst = Hbar*sig2bTru;
  end
  
  ytext = [0.25]; xtext = [7.5*xlim2/10]; str = ['$$n_{z}=$$'   sprintf('%d',  length(find(defvec)))]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
end % if ~UPDATE_FIGS

if xIsTrue
  numCausalSNPsTru = floor(pi1Tru*nsnps_from_full_LD_build);
  sigb2TotalTru    = pi1Tru*sig2bTru;
  phenotypicVarianceExplainedPerCausalSNPTruEst = Hbar_from_full_LD_build*sig2bTru;
  h2True_Est = phenotypicVarianceExplainedPerCausalSNPTruEst*numCausalSNPsTru;
end

  figure(figNum_QQplot);
  if ~xIsTrue
  if numCausalSNPsEst < 1e4
    ytext = [0.25]; xtext = [6.75*xlim2/10]; str = ['$$\hat{n}_{causal}=$$'   sprintf('%d',  numCausalSNPsEst)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  else
    ytext = [0.25]; xtext = [6.75*xlim2/10]; str = ['$$\hat{n}_{causal}=$$'   sprintf('%.2e',numCausalSNPsEst)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  end
  if length(paramsTrue)
    if numCausalSNPsTru < 1e4
      ytext = [0.25]; xtext = [6.0*xlim2/10]; str = ['$$n_{causal}=$$'       sprintf('%d',  numCausalSNPsTru)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
    else
      ytext = [0.25]; xtext = [6.0*xlim2/10]; str = ['$$n_{causal}=$$'       sprintf('%.2e',numCausalSNPsTru)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
    end
    ytext = [0.25];   xtext = [1.75*xlim2/10]; str = ['$$h_0^2=$$'                sprintf('%.1f',h2True_Est)];    atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  
  if ~xIsTrue
    ytext = [0.25];     xtext = [3.0*xlim2/10];  str = ['$$\hat{\sigma}^2_0=$$'    sprintf('%.3f',sig0^2)];   atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  
  if ~xIsTrue
    ytext = [5.25*ylim2/7]; xtext = [6.25*xlim2/16]; str = ['$$\hat{\pi}_1=$$'         sprintf('%.2g',pi1Est)];   atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  else
    figure(figNum_QQplot);
    ytext = [5.25*ylim2/7]; xtext = [5.25*xlim2/16]; str = ['$$\pi_1=$$'              sprintf('%.2g',pi1)];   atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  if ~xIsTrue
    ytext = [5.25*ylim2/7]; xtext = [4.0*xlim2/16]; str = ['$$\hat{\sigma}^2_\beta=$$' sprintf('%.2g',sig2bEst)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  else
    figure(figNum_QQplot);
    ytext = [5.25*ylim2/7]; xtext = [2.75*xlim2/16]; str = ['$$\sigma^2_\beta=$$'    sprintf('%.2g',sigb^2)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  if ~xIsTrue
    ytext = [5.25*ylim2/7]; xtext = [1.5*xlim2/16]; str = ['$$\hat{h}^2=$$'            sprintf('%.2f',h2Est)];    atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  if length(paramsTrue)
    ytext = [5.25*ylim2/7]; xtext = [0.5*xlim2/16]; str = ['$$h^2=$$'               sprintf('%.2f',h2True_Est)]; atext = text(xtext,ytext,str,'Interpreter','Latex','FontSize',paramFontSize);
  end
  
  fig=figure(figNum_QQplot);
  infix = '';
  if xIsTrue
    figFileName = sprintf('%s/qq%s_pi1_1em%d_h2_p%d_betai_%d%s.eps', outDir, figInfix, int8(-log10(pi1Tru)), int8(10*h2True), betai, infix);
  else
    figFileName = sprintf('%s/qq_1x1%s%s%s.eps', outDir, phenoName, figInfix, infix);
  end
  
  fprintf(1, 'Writing %s...\n', figFileName);
  saveas(gcf,figFileName,'epsc');
  disp('done')
  if betai>1 & UPDATE_FIGS
    close(figNum_QQplot);
  end

fprintf(1,'sig0^2=%f pi1=%f sigb.^2=%f, b=%g, pp=%g\n',sig0^2,pi1,sigb.^2,b,pp);
nSNPsThreshold = 0;           % Require at least this many SNPs per zvals_disc bin to be included in any given rep.
nSNPsAvgPerRepThreshold = 4;  % Require at least this many SNPs on average per rep for each zvals_disc bin for the bins to be included.

% For calculating fraction of chip variance (or additive genetic variance) explained by SNPs on chip passing significance threshold
numeratorSum1  = 0;
numeratorSum2  = 0;
denominatorSum = 0;
zthresh1 = -norminv(5e-8/2);            % zthresh1 = 5.4513 : Usual GWAS threshold
zthresh2 = -norminv(1e-6/2);            % zthresh2 = 4.8916 : "Lowering the bar"
%minusLog10p_t1 = -log10(2*(normcdf(-zthresh1)));
%minusLog10p_t2 = -log10(2*(normcdf(-zthresh2)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  resstruct = struct();
  if ~xIsTrue
    resstruct.lam_model = lamGC_median_QQpredNet;
    resstruct.sig2_0   = sig0^2;
    resstruct.sig2_b   = sigb^2;
    resstruct.sig2_a   = siga^2;
    resstruct.b        = b;
    resstruct.pi1      = pi1;
    resstruct.pp       = pp;
    resstruct.lam_data = lamGC_median_QQobsNet;
    resstruct.lamGC_mean_Zobs        = lamGC_mean_Zobs;
    resstruct.lamGC_median_Zobs      = lamGC_median_Zobs;
    resstruct.lamGC_median_ZobsNet   = lamGC_median_ZobsNet;
    resstruct.lamGC_median_QQobsNet  = lamGC_median_QQobsNet;
    resstruct.lamGC_median_QQpredNet = lamGC_median_QQpredNet;
    resstruct.lamGC_median_QQobsAvg  = lamGC_median_QQobsAvg;
    resstruct.lamGC_median_QQpredAvg = lamGC_median_QQpredAvg;
    resstruct.ncausal  = numCausalSNPsEst;
    resstruct.h2       = h2Est;
    %resstruct.propTagVar_t1 = propTagVar_t1;
    %resstruct.propTagVar_t2 = propTagVar_t2;
    resstruct.data_logp      = data_logp;
    resstruct.data_logq      = data_logq;
    resstruct.data_ci1       = data_ci1;
    resstruct.data_ci2       = data_ci2;
    resstruct.modelFit_logp  = modelFit_logp;
    resstruct.modelFit_logq  = modelFit_logq;
    resstruct.n_z            = length(find(defvec));
    resstruct.qqHLplotsMainCell = qqHLplotsMainCell;
  else
    resstruct.modelTru_logp     = modelTru_logp;
    resstruct.modelTru_logq     = modelTru_logq;
    resstruct.h2                = h2True;
    resstruct.true_lam_model    = lamGC_median_QQpredNet;
    resstruct.numCausalSNPsTru  = numCausalSNPsTru;
    resstruct.h2True_Est          = h2True_Est;
    resstruct.sigb2             = sigb^2;
    resstruct.pi1               = pi1;
  end
end
