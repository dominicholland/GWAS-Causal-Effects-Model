
% Dominic Holland
% https://www.biorxiv.org/content/early/2018/06/07/133132

function [yvals_mean yvals_count] = histmean_dh(xvec,yvec,xvals)

step = xvals(2)-xvals(1);
edges = [xvals-step/2 xvals(end)+step/2];
[h, edges, bin] = histcounts(xvec, edges);

yvals_count = h;
yvals_mean  = NaN(size(xvals));
for i = 1:length(xvals)
  ivec = (bin == i);
  yvals_mean(i) = mean(yvec(ivec));
end
