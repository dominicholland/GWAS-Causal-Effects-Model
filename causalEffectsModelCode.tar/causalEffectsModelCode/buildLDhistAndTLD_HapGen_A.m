
% Dominic Holland
% https://www.biorxiv.org/content/early/2018/06/07/133132

% buildLDhistAndTLD_HapGen_A

ZERO_OUT_NOISE = true;    % Is the "noise" noise? Keep "noise" for LDr2hist, filter out for tld. Of course, tld can also be estimated from LDr2hist.
%ZERO_OUT_NOISE = false;
noiseThreshold_r2 = 0.01;  % E.g., 0.05 ==> noiseThreshold_r = sqrt(noiseThreshold_r2) = 0.2236 : For r^2<0.05 set r^2 to 0.

!hostname > hostname.txt;
computerName = textread('hostname.txt','%s');
computerName = computerName{1};
fprintf(1,'hostname is %s\n',computerName);

if strcmp('ip24.ucsd.edu', computerName)
  ip24LocalDisk = '/space-local/holland/GWAS_data';
  fprintf(1,'hostname is %s\n',computerName);
  fprintf(1,'Using local disk %s\n', ip24LocalDisk);
  genotypepath    = [ip24LocalDisk '/SimuPop/EUR'];
  dataPathSimSNPs = [ip24LocalDisk '/SimuPop/sundar/To_Dominic'];
  dataPath9m      = [ip24LocalDisk '/new_9m_SNPs_processed_summary/GWAS_Annot'];
  inDir           = [ip24LocalDisk '/SynGen2'];
  outDir          = [ip24LocalDisk '/SynGen2'];
  if ~exist( inDir,  'dir'),  fprintf(1, 'inDir %s does not exist...\n', inDir);  keyboard;  end;
  if ~exist( outDir, 'dir'),  mkdir(outDir);  end;  fprintf(1, 'outDir is %s\n', outDir);
else
  fprintf(1,'hostname is %s\n',computerName);
  fprintf(1,'This could take forever...\n');
  keyboard
  genotypepath     = '/home/cfan/GWAS_data/SimuPop/EUR';
  dataPathSimSNPs  = '/home/ssundar/To_Dominic';
  dataPath9m       = '/space/syn03/1/data/GWAS/new_9m_SNPs_processed_summary/GWAS_Annot';
  inDir            = '/space/md10/8/data/holland/genetics/SynGen';
  outDir           = '/space/md10/8/data/holland/genetics/SynGen2';
  if ~exist( inDir,  'dir'),  fprintf(1, 'inDir %s does not exist...\n', inDir);  keyboard;  end;
  if ~exist( outDir, 'dir'),  mkdir(outDir);  end;  fprintf(1, 'outDir is %s\n', outDir);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_fullFileName = [outDir '/chr_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];        % chr  1x11015833  11015833  int8
G_fullFileName = [outDir '/G_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];          % G  1000x11015833  11015833000  int8
%M_fullFileName = [outDir '/mafvec.mat'];

if ~exist(G_fullFileName, 'file') | ~exist(C_fullFileName, 'file')
  G1k_fullFileName = [outDir '/G1k.mat'];   % Contains G1k and chrAll.  G1k is (1000 X 80378054).   See  buildLD_from_HG_compatibleWith_hg18.m
  if ~exist(G1k_fullFileName, 'file')
    
    load([dataPathSimSNPs '/snp_detail.mat']);         % Load meta data from Sundar
   %load([dataPathSimSNPs '/beta_true.mat']);          % T beta_true exon_all_ind utr3_all_ind utr5_all_ind val_all val_enrr y_true
    load([dataPathSimSNPs '/beta_true.mat'],'y_true'); % y_true 100000x27   100000 subjects
    nsubj_total = size(y_true,1);  clear y_true;
   %load([dataPathSimSNPs '/beta_true.mat'],'beta_true');
   %nsnps_total = size(beta_true,1);  % <----- 80378054
    nsnps_total = sum(sum(snp_size)); % <----- 80378054
    
    % Randomly choose 1000 subjects from the 100000. Use their genotypes to build LD stuff.
    permvec = randperm(nsubj_total);
    subjIndxVec1000 = permvec(1:1000);   % Use the SAME subjects for all chromosomes!
    
    n0 = 0;
   %n0 = 35063245;
    G1k = -1*ones(1000, nsnps_total, 'int8');
    chrAll = zeros(1,nsnps_total,'int8');
    for i=1:nchrom
   %for i=7:nchrom
      for j=1:nchunk(i)
        fprintf(1,'Reading i=%d of %d j=%d of %d now:%s\n',i,nchrom,j,nchunk(i),datestr(now,'HH:MM:SS'));
        fileprefix=sprintf('%s/chr%d_chunk%d',genotypepath,i,j);
        bedprefix=[fileprefix,'.bed'];
        if exist(bedprefix,'file')>0
         %X = double(PlinkRead_binary2(nsubj_total,snp_size(i,j),fileprefix));
         %X = (X-repmat(mean(X,1),nsubj_total,1));
          n1=n0+snp_size(i,j);
          tic
          X = PlinkRead_binary2(nsubj_total,snp_size(i,j),fileprefix);  % int8
          toc
          if size(X,2) ~= snp_size(i,j),  keyboard;  end
         %X = X(1:1000,:);           % Take the 1st 1000 subjects. Build binary LD matrix from this agregated over whole genome. How does it compare with that from 1000Genomes Phase 3?
          X = X(subjIndxVec1000,:);  % Take a random sampling of 1000 subjects. Build binary LD matrix from this agregated over whole genome. How does it compare with that from 1000Genomes Phase 3?
          tic
          G1k(:,n0+1:n1) = X;
          chrvec = i*ones(1,snp_size(i,j));
          chrAll(n0+1:n1) = chrvec;
          toc
          clear X;
          n0=n1;
          if n0 > nsnps_total,  keyboard;  end
        end
      end
    end
    
    fprintf(1,'Writing %s...',G1k_fullFileName);
    save(G1k_fullFileName, 'G1k', 'chrAll','-v7.3');
    fprintf(1,'done.\n');
    
  else
    load(G1k_fullFileName);  % G1k and chrAll; G1k is (1000 X 80378054). % 80 GB in memory; 2.1G file.
  end
  
  % G1k is  1000 x 80378054;  NOTE, for 1kG Phase-3 real data, G1k is  503 x 81271745.
  
  nsnps_HG_all = size(G1k,2);  % 80378054;
 %nsnps_9m_all =  9279485;
  
  nsubj = size(G1k,1);  % 1000
  
  if 1
    % PLAN: Get rid of SNPs for which (1), (2), or (3) apply:
    % (1) SNPs with no heterozygosity (zero variation in allele count, i.e., maf==0 --> for a given SNP all subjects have genotype=0, so that maf==0; maf==1 is a contradiction in terms --> all have genotype=2);
    %     Note: if all subjects have genotype=1, this implies nonzero variation, given by the heterozygosity: H = 2*maf*(1-maf) = 0.5;
    % (2) Singleton SNPs (SNPs for which only 1 subject has a different allele count to all the other subjects);
    % (3) SNPs for which the call rate is less than 90% (i.e., for which less than 90 percent of subjects have useful data (useful data means 0, 1, or 2 for allele count, not -1).
    % 
    % For (3), 90 percent seems reasonable. Don''t want it too low at least partly because missing allele count will be replaced by the mean: the more missing SNPs there are, the greater the impact of this change.
    % Don''t want it too high because then one is eliminating potentially useful/informative SNPs that "just happen" to be missing a few subjects.
    % (What are the reasons behind missingness? If there are even a few missing subjects for a SNP, is that indicative of a real problem with that SNP?)
    % 
    % This leads to snpsToEliminate as defined below.
    
    % Some subjects have "-1" for allele count: these need to be excluded from the tallies.
    %nsubjsWithSNPData_vec = nsubj-sum(G1k==-1,1);   % For HapGen, by design nothing is missing..... no "-1"s.
    nsubjsWithSNPData_vec = nsubj;
    %nsubjsWithSNPData_99percentile_vec = nsubjsWithSNPData_vec - round(0.01*(nsubjsWithSNPData_vec));
    
    
    % For removing SNPs with zero heterozygopsity AND singletons:
    snpsWithLowVariationIndsLogical_NoSingletons = sum(~G1k,1)   >=    nsubjsWithSNPData_vec-1;
							 % Note:
							 % xx = sum(~G1k==1,1) >  nsubjsWithSNPData_vec-1;      length(find(xx)) == 55789172  ==> 24588882 SNPs that have at least one subject with non-zero genotype (i.e., including singletons). 
							 % xx = sum( G1k==1,1) >= nsubjsWithSNPData_vec-1;      length(find(xx)) == 0
							 % yy = sum( G1k==2,1) >= 2*(nsubjsWithSNPData_vec-1);  length(find(yy)) == 0
    
    snpIndsLogical_NoSingletons = ~snpsWithLowVariationIndsLogical_NoSingletons;
    snpInds_NoSingletons        = find(snpIndsLogical_NoSingletons);
    nsnps_NoSingletons          = length(snpInds_NoSingletons);  % 19902704
    
    
    % For removing SNPs where 99.5% or more of subjects have genotype==0:
    minPercentSubjsWithNonIdenticalSNP = 0.5;
    minNumSubjsWithNonIdenticalSNP    = ceil(minPercentSubjsWithNonIdenticalSNP*nsubj/100);
    snpsWithLowVariationIndsLogical_0p5pc = sum(~G1k,1)   >=    nsubjsWithSNPData_vec-minNumSubjsWithNonIdenticalSNP;
    snpIndsLogical_0p5pc = ~snpsWithLowVariationIndsLogical_0p5pc;
    snpInds_0p5pc        = find(snpIndsLogical_0p5pc);
    nsnps_0p5pc          = length(snpInds_0p5pc);                % 13443368
    
    
    % For removing SNPs where 99% or more of subjects have genotype==0:
    minPercentSubjsWithNonIdenticalSNP = 1;
    minNumSubjsWithNonIdenticalSNP    = ceil(minPercentSubjsWithNonIdenticalSNP*nsubj/100);
    snpsWithLowVariationIndsLogical_1pc = sum(~G1k,1)   >=    nsubjsWithSNPData_vec-minNumSubjsWithNonIdenticalSNP;
    snpIndsLogical_1pc = ~snpsWithLowVariationIndsLogical_1pc;   % NOTE: All of these are in maf_gt_5em3_indsLogical -- see below.
    snpInds_1pc        = find(snpIndsLogical_1pc);
    nsnps_1pc          = length(snpInds_1pc);                    % 11142640 NOTE: All of these are in maf_gt_5em3_indsLogical -- see below.
    
    
    mafvec_all     = mean(G1k,1)/2;                                 % 80378054 min=0;      max=0.5435; num snps with maf>0.5 is 51044;  Can't use this if there are -1s. %'
    maf_gt_5em3_indsLogical = mafvec_all>=0.005;                    % 11442668 SNPs  NOTE: Contains all of snpIndsLogical_1pc
    
    fullFileName = [outDir '/snpIndsLogical_NoSingletons_0p5pc_1pc_maf_gt_5em3'];
    fprintf(1,'Writing %s...',fullFileName);
    save(fullFileName, 'snpIndsLogical_NoSingletons', 'snpIndsLogical_0p5pc', 'snpIndsLogical_1pc', 'maf_gt_5em3_indsLogical', '-v7.3');
    fprintf(1,'done.\n');
    
  else
    
    fullFileName = [outDir '/snpIndsLogical_NoSingletons_0p5pc_1pc_maf_gt_5em3'];
    fprintf(1,'Reading %s...',fullFileName);
    load(fullFileName);
    fprintf(1,'done.\n');
  end
  
  mafvec_NoSingletons = mean(G1k(:,snpIndsLogical_NoSingletons),1)/2;  % 19902704 min=1e-3;   max=0.5435; num snps with maf>0.5 is 51044;  Can't use this if there are -1s. %'
  mafvec_0p5pc        = mean(G1k(:,snpIndsLogical_0p5pc),1)/2;         % 13443368 min=0.0055; max=0.5435; num snps with maf>0.5 is 51044;  
  mafvec_1pc          = mean(G1k(:,snpIndsLogical_1pc),1)/2;           % 11142640 min=0.0030; max=0.5435; num snps with maf>0.5 is 51044;  
  
  fullFileName_HG80p3m_1kGPIII14p9m_RemappingIndices = [inDir '/1kGPIII14p9m_n_HG80p3m_commonIndices.mat'];
  fprintf(1,'Reading %s...',fullFileName_HG80p3m_1kGPIII14p9m_RemappingIndices);
  load(fullFileName_HG80p3m_1kGPIII14p9m_RemappingIndices, 'i1kGPIII14p9m_1kGPIII14p9m_n_HG80p3m', 'iHG80p3m_1kGPIII14p9m_n_HG80p3m', 'iHG80p3m_HG80p3m_n_1kGPIII14p9m', 'i1kGPIII14p9m_HG80p3m_n_1kGPIII14p9m');
  fprintf(1,'done.\n');
  
  iHG80p3m_HG80p3m_n_1kGPIII14p9m_logical = false(1,nsnps_HG_all);
  iHG80p3m_HG80p3m_n_1kGPIII14p9m_logical(iHG80p3m_HG80p3m_n_1kGPIII14p9m) = true;  % 14651426
  
  %snpIndsLogical = iHG80p3m_HG80p3m_n_1kGPIII14p9m_logical & snpIndsLogical_NoSingletons;
  %nsnps = length(find(snpIndsLogical));    % 14054114
  
  %snpIndsLogical = iHG80p3m_HG80p3m_n_1kGPIII14p9m_logical & snpIndsLogical_0p5pc;
  %nsnps = length(find(snpIndsLogical));    % 12439289
  
  snpIndsLogical = iHG80p3m_HG80p3m_n_1kGPIII14p9m_logical & snpIndsLogical_1pc;
  nsnps = length(find(snpIndsLogical));     % 11015833
  
  %snpIndsLogical = iHG80p3m_HG80p3m_n_1kGPIII14p9m_logical & maf_gt_5em3_indsLogical;
  %nsnps = length(find(snpIndsLogical));    % 11250473
  
  %%%%%%%%%%%%
  load /space/md10/8/data/holland/genetics/SynGen2/snpidlist_HG80p3m_HG80p3m_n_1kGPIII14p9m.mat;  % --> snpidlist_HG80p3m_HG80p3m_n_1kGPIII14p9m   size 14651426x1   bytes 1937981654   type cell; takes a few minutes.
  snpInds = find(snpIndsLogical);  % 11015833 indices into 80378054 array;
  [snpinds_dum ia ib] = intersect(iHG80p3m_HG80p3m_n_1kGPIII14p9m, snpInds, 'stable');
  snpIDs = snpidlist_HG80p3m_HG80p3m_n_1kGPIII14p9m(ia);
  tic
  fullFileName = [outDir '/snpIDs_11p3m.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'snpIDs');
  fprintf(1,'done.\n');
  toc
  clear snpinds_dum ia ib;
  %%%%%%%%%%%%
  
  chr       = chrAll(snpIndsLogical);
  G         = G1k(:,snpIndsLogical);
  %clear G1k;
  
 %mafvec = (sum(G,1) + sum(G==-1,1))./(2*sum(G~=-1,1));        % min 0.001988071570577;  max 0.5.
  mafvec = mean(G,1)/2;  % Can't use this if there are -1s. %'
  fullFileName = [outDir '/chr_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'chr');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/G_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'G','-v7.3');
  fprintf(1,'done.\n');
  
  fullFileName = [outDir '/mafvec_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];
  fprintf(1,'Writing %s...',fullFileName);
  save(fullFileName, 'mafvec');
  fprintf(1,'done.\n');
  mafvecSingle = single(mafvec);
else
  fprintf(1,'Reading %s...',G_fullFileName);
  load(G_fullFileName);  % G  1000x11015833  11015833000  int8
  fprintf(1,'done.\n');
  
  mafvec = mean(G,1)/2;
  
  fprintf(1,'Reading %s...',C_fullFileName);
  load(C_fullFileName);
  fprintf(1,'done.\n');
end

hvec = 2*mafvec.*(1-mafvec);

nsubj = size(G,1);  %      1000
nsnps = size(G,2);  %  11015833

W = single(G);      %

ldr2binsNum = 100;  %  50?
ldrbinsNum  = 200;  % 100?
ldr2binsEdges = linspace( 0,1,ldr2binsNum+1);
ldrbinsEdges  = linspace(-1,1,ldrbinsNum +1);
ldr2binsCenters = nan(1,ldr2binsNum); for i=1:ldr2binsNum, ldr2binsCenters(i) = (ldr2binsEdges(i+1)+ldr2binsEdges(i))/2; end
ldrbinsCenters  = nan(1,ldrbinsNum);  for i=1:ldrbinsNum,  ldrbinsCenters(i)  = (ldrbinsEdges(i+1) +ldrbinsEdges(i))/2; end

numSNPsChriVec     = nan(22,1);
blockWidth         =  5000;
 blockExtension    = 25000;  % Mostly have used 50000. Try 25000? NOTE: Output files without blockExtension in their name have used 50000.
%blockExtension    = 50000;  % Mostly have used 50000. Try 25000? NOTE: Output files without blockExtension in their name have used 50000.
cumulativeSNPCount = 0;

numBlocksGrandTotal = ceil(nsnps/blockWidth);

clear tldvec LDr2hist;
tldvec   = nan(nsnps,1);
LDr2hist = 0;  % REMOVE!
if 0 % REMOVE!
LDr2hist = zeros(nsnps,ldr2binsNum);
end % REMOVE!
Hhist    =   nan(nsnps,ldr2binsNum);

beginningOfTime = now;  % This section takes baout 24 hrs.
for chri = 1:22
  chriInds  = find(chr == chri);
  nsnpsChri = length(chriInds);
  
  blockNum = 0;
  numBlocks = ceil(nsnpsChri/blockWidth);
  
  for blocki = 1:blockWidth:nsnpsChri
    blockNum   = blockNum + 1;
    blockStart = cumulativeSNPCount+blocki;
    blockEnd   = cumulativeSNPCount+min(nsnpsChri,blocki+blockWidth-1);
    
    isearchStart = cumulativeSNPCount+max(1,blocki-blockExtension);
    isearchEnd   = cumulativeSNPCount+min(nsnpsChri,blocki+blockWidth-1+blockExtension);
    
    snpsvec1 = [blockStart:blockEnd];
    snpsvec2 = [isearchStart:isearchEnd];
    nsnpsj1  = length(snpsvec1);
    nsnpsj2  = length(snpsvec2);
    
    rmat = corr(W(:,snpsvec1),W(:,snpsvec2));     % NOTE: If W has NaN (not -1) for missing data, then correlation between any pair of SNPs for which there is at least one NaN will be NaN.
    r2mat = rmat.^2;
   %if ZERO_OUT_NOISE,  r2mat(r2mat<noiseThreshold_r2) = 0;  end
    
    numBlocksCompleted = ceil(blockEnd/blockWidth);
    
   %rmat1  = corr(W(:,snpsvec1),W(:,snpsvec1));
   %r2mat1 = rmat1.^2;
   %figure(1); clf; imagesc(rmat1);  colormap(blueblackred); colorbar; axis equal; axis tight; drawnow;
   %figure(2); clf; imagesc(r2mat1); colormap(blueblackred); colorbar; axis equal; axis tight; drawnow;
    
   %tldvec(snpsvec1) = sum(r2mat,2);
    
    time0 = now;
    for k=1:nsnpsj1
     %hldr2 = hist(r2mat(k,:),ldr2binsCenters);
     %snpj = snpsvec1(k);
     %LDr2hist(snpj,:) = hldr2;
      
      [Hvals Cntvals] = histmean_dh(r2mat(k,:), hvec(snpsvec2), ldr2binsCenters);
      
      LDr2hist(snpsvec1(k),:) = Cntvals;
      % ...SAME as:
     %LDr2hist(snpsvec1(k),:) = hist(r2mat(k,:),ldr2binsCenters);
      Hhist(snpsvec1(k),:)    = Hvals;    % Hvals will have NaN where Cntvals is 0.
      
     %if ~mod(k,1e3) | k==nsnpsj1
     %  s1 = datestr(now,'dddd HH:MM:SS');
     %  s2 = datestr(time0+(now-time0)*nsnpsj1/k,'dddd HH:MM:SS');
     %  fprintf(1,['chr %d  block %d of %d (%d of %d): k=%d of %d  (now=%s done=%s)\r\b'],...
     %            chri,blockNum,numBlocks,numBlocksCompleted,numBlocksGrandTotal,k,nsnpsj1,s1,s2);
     %end
    end
    
    % Keep "noise" for LDr2hist -- can control later by ignoring lower r^2 bins.
    % But, eliminate "noise" for tld estimate.... Of course, tld can also be estimated from LDr2hist.
    if ZERO_OUT_NOISE,  r2mat(r2mat<noiseThreshold_r2) = 0;  end
    tldvec(snpsvec1) = sum(r2mat,2);
    
   %fprintf(1,'\n');
    s1 = datestr(now,'dddd HH:MM:SS');
    s2 = datestr(beginningOfTime+(now-beginningOfTime)*numBlocksGrandTotal/numBlocksCompleted,'dddd HH:MM:SS');
    fprintf(1,['chr %d  block %d of %d (%d of %d): (now=%s done=%s)\r\b'],...
               chri,blockNum,numBlocks,numBlocksCompleted,numBlocksGrandTotal,s1,s2);
  end
  
  numSNPsChriVec(chri) = nsnpsChri;
  cumulativeSNPCount = cumulativeSNPCount + nsnpsChri;
end

fileNameInfix = [];
fileNameInfix = ['_BlockExt_' num2str(blockExtension)];

fullFileName = [outDir '/Hhist' fileNameInfix '.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'Hhist', '-v7.3');
fprintf(1,'done.\n');

%fullFileName = [outDir '/LDr2hist' fileNameInfix '.mat'];
 fullFileName = [outDir '/LDr2hist' fileNameInfix '_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];
%fullFileName = [outDir '/LDr2hist_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'LDr2hist', '-v7.3');
fprintf(1,'done.\n');

if ZERO_OUT_NOISE, fileNameInfix = [fileNameInfix '_zontr2_p' num2str(100*noiseThreshold_r2)];  end

%fullFileName = [outDir '/TLDr2' fileNameInfix '.mat'];
fullFileName = [outDir '/TLDr2' fileNameInfix '_HG80p3m_HG80p3m_n_1kGPIII14p9m_1pc.mat'];
fprintf(1,'Writing %s...',fullFileName);
save(fullFileName, 'tldvec', '-v7.3');
fprintf(1,'done.\n');
